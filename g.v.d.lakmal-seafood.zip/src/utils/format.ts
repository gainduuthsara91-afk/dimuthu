/**
 * Formats a numerical price into Sri Lankan Rupees (Rs. / LKR)
 * e.g., 1800 -> "Rs. 1,800"
 */
export function formatPrice(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return 'Rs. 0';
  }
  return `Rs. ${Math.round(amount).toLocaleString('en-LK')}`;
}
