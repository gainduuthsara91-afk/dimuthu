export type SeafoodCategory = 
  | 'all'
  | 'tuna'
  | 'prawns'
  | 'crabs'
  | 'reef-fish'
  | 'boxes';

export type PrepOption = 
  | 'Whole (Cleaned, Scaled & Gutted)'
  | 'Prime Steaks (Center-Cut)'
  | 'Skin-on Fillets (Boneless)'
  | 'Sashimi-Grade Block (Sushi Ready)'
  | 'Live / Shell-on Chilled'
  | 'Headless Cleaned (Gutted)'
  | 'Prime Steaks (Center-Cut, Headless)'
  | 'Skin-on Fillets (Boneless, Headless)'
  | (string & {});

export interface SeafoodProduct {
  id: string;
  name: string;
  scientificName: string;
  category: SeafoodCategory;
  pricePerKg: number;
  minWeightKg: number;
  image: string;
  badge?: string;
  origin: string;
  harvestMethod: string;
  landedTime: string;
  grade: string;
  flavorProfile: string;
  texture: string;
  culinaryUses: string[];
  stockKg: number;
  prepOptions: PrepOption[];
  sustainabilityRating: string;
  description: string;
}

export interface CartItem {
  id: string;
  productId: string;
  product: SeafoodProduct;
  selectedPrep: PrepOption;
  weightKg: number;
  quantity: number;
  totalPrice: number;
}

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  packagingFee: number;
  totalAmount: number;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  address: string;
  city: string;
  postalCode: string;
  deliverySlot: string;
  deliveryInstructions?: string;
  packagingType: 'signature-ice' | 'eco-wool' | 'insulated-gift';
  paymentMethod: 'card' | 'apple-pay' | 'cod' | 'bank-wire';
  paymentStatus: 'paid' | 'pending-cod' | 'wire-pending';
  orderStatus: 'received' | 'prepped' | 'in-transit' | 'delivered';
  temperatureLog: string;
  _hp_trap?: string;
  _formOpenedAt?: number;
}
