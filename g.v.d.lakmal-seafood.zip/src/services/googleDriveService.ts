import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  signOut,
  GoogleAuthProvider,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { Order } from '../types/seafood';

// Initialize Firebase App instance safely (prevent duplicate initialization)
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

// Configure Google Auth Provider with requested Drive Scopes
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive');
provider.addScope('https://www.googleapis.com/auth/drive.file');

// In-Memory Token Cache (strictly NEVER stored in localStorage or sessionStorage as required)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

export interface DriveFileInfo {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string;
  webViewLink?: string;
  iconLink?: string;
}

/**
 * Initialize Drive authentication state listener.
 */
export const initDriveAuth = (
  onAuthChange?: (user: User | null, token: string | null) => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user && cachedAccessToken) {
      if (onAuthChange) onAuthChange(user, cachedAccessToken);
    } else {
      if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthChange) onAuthChange(null, null);
      }
    }
  });
};

/**
 * Sign in with Google to grant Drive access.
 */
export const googleSignInWithDrive = async (): Promise<{ user: User; accessToken: string }> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Could not acquire Google Drive access token.');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Drive sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Disconnect/logout and clear in-memory token.
 */
export const googleSignOutDrive = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

/**
 * Get the current in-memory access token.
 */
export const getDriveAccessToken = (): string | null => {
  return cachedAccessToken;
};

/**
 * Find or create dedicated folder 'G.V.D.Lakmal Seafood Records' on Google Drive.
 */
export const getOrCreateSeafoodFolder = async (folderName = 'G.V.D.Lakmal Seafood Records'): Promise<string> => {
  if (!cachedAccessToken) {
    throw new Error('Not authenticated with Google Drive. Please sign in first.');
  }

  // 1. Check if folder already exists
  const query = `name = '${folderName}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
  const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name)`;
  const searchRes = await fetch(searchUrl, {
    headers: { Authorization: `Bearer ${cachedAccessToken}` }
  });

  if (!searchRes.ok) {
    throw new Error(`Drive folder query failed: ${searchRes.statusText}`);
  }

  const searchData = await searchRes.json();
  if (searchData.files && searchData.files.length > 0) {
    return searchData.files[0].id;
  }

  // 2. Create the folder if not present
  const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cachedAccessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
      description: 'Official digital order receipts and catch logs for G.V.D.Lakmal Seafood'
    })
  });

  if (!createRes.ok) {
    throw new Error(`Failed to create Google Drive folder: ${createRes.statusText}`);
  }

  const createData = await createRes.json();
  return createData.id;
};

/**
 * Upload a text or binary file to Google Drive folder using multipart upload.
 */
export const uploadFileToDrive = async ({
  name,
  mimeType,
  content,
  folderId
}: {
  name: string;
  mimeType: string;
  content: string | Blob;
  folderId?: string;
}): Promise<DriveFileInfo> => {
  if (!cachedAccessToken) {
    throw new Error('Not authenticated with Google Drive. Please sign in first.');
  }

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadata: any = {
    name,
    mimeType
  };
  if (folderId) {
    metadata.parents = [folderId];
  }

  let body: Blob;
  const metadataBlob = new Blob([
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    `Content-Type: ${mimeType}\r\n\r\n`
  ], { type: 'text/plain' });

  const contentBlob = typeof content === 'string' ? new Blob([content], { type: mimeType }) : content;
  const closeBlob = new Blob([closeDelimiter], { type: 'text/plain' });

  body = new Blob([metadataBlob, contentBlob, closeBlob]);

  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,createdTime,webViewLink,iconLink', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cachedAccessToken}`,
      'Content-Type': `multipart/related; boundary=${boundary}`
    },
    body
  });

  if (!res.ok) {
    const errorBody = await res.text().catch(() => '');
    throw new Error(`Upload to Google Drive failed: ${res.statusText} ${errorBody}`);
  }

  return await res.json();
};

/**
 * List files stored in the dedicated Seafood folder or root.
 */
export const listSeafoodDriveFiles = async (folderId?: string): Promise<DriveFileInfo[]> => {
  if (!cachedAccessToken) {
    return [];
  }

  let q = 'trashed = false';
  if (folderId) {
    q += ` and '${folderId}' in parents`;
  }

  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&orderBy=createdTime desc&fields=files(id,name,mimeType,size,createdTime,webViewLink,iconLink)&pageSize=30`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${cachedAccessToken}` }
  });

  if (!res.ok) {
    throw new Error(`Failed to list files: ${res.statusText}`);
  }

  const data = await res.json();
  return data.files || [];
};

/**
 * Delete a file on Google Drive (requires user confirmation before calling).
 */
export const deleteFileFromDrive = async (fileId: string): Promise<void> => {
  if (!cachedAccessToken) {
    throw new Error('Not authenticated with Google Drive.');
  }

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${cachedAccessToken}` }
  });

  if (!res.ok && res.status !== 204) {
    throw new Error(`Failed to delete file from Drive: ${res.statusText}`);
  }
};

/**
 * Save an order receipt formatted document to Google Drive.
 */
export const saveOrderReceiptToGoogleDrive = async (order: Order): Promise<DriveFileInfo> => {
  const folderId = await getOrCreateSeafoodFolder();

  const receiptContent = `
=====================================================
G.V.D.LAKMAL SEAFOOD — OFFICIAL ORDER RECEIPT
Mirissa Fishery Harbor, Southern Province, Sri Lanka
Inquiries & WhatsApp: +94 77 878 8454
Owner Email: gainduuthsara91@gmail.com
=====================================================

ORDER IDENTIFIER: #${order.id}
DATE & TIME: ${order.createdAt || new Date().toLocaleString()}
STATUS: ${order.orderStatus ? order.orderStatus.toUpperCase() : 'CONFIRMED'}
PAYMENT METHOD: CASH ON DELIVERY (COD)
COLD-CHAIN VERIFICATION: 0°C–2°C Sea-Ice Transport Logged

-----------------------------------------------------
CUSTOMER DETAILS:
-----------------------------------------------------
Name:      ${order.customerName}
Phone:     ${order.customerPhone}
Email:     ${order.customerEmail}
Address:   ${order.address}, ${order.city} (${order.postalCode || 'N/A'})
Window:    ${order.deliverySlot}
Notes:     ${order.deliveryInstructions || 'None'}

-----------------------------------------------------
ORDERED FRESH CATCH ITEMS:
-----------------------------------------------------
${order.items.map((item, idx) => {
  const itemName = item.product?.name || item.productId;
  const price = (item.totalPrice * item.quantity).toFixed(2);
  return `${idx + 1}. ${itemName}\n   - Cut: ${item.selectedPrep || 'Standard'}\n   - Weight: ${item.weightKg} kg (Qty: ${item.quantity})\n   - Amount: Rs. ${Number(price).toLocaleString('en-LK')}`;
}).join('\n\n')}

-----------------------------------------------------
PAYMENT BREAKDOWN:
-----------------------------------------------------
Subtotal:          Rs. ${Math.round(order.subtotal).toLocaleString('en-LK')}
Chilled Delivery:  ${order.deliveryFee === 0 ? 'FREE' : `Rs. ${Math.round(order.deliveryFee).toLocaleString('en-LK')}`}
TOTAL DUE (COD):   Rs. ${Math.round(order.totalAmount).toLocaleString('en-LK')}

=====================================================
Thank you for supporting Mirissa's artisanal fishermen!
Official Google Drive Archive — G.V.D.Lakmal Seafood
=====================================================
  `.trim();

  const fileName = `Receipt_Order_${order.id}_${order.customerName.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;

  return await uploadFileToDrive({
    name: fileName,
    mimeType: 'text/plain',
    content: receiptContent,
    folderId
  });
};

/**
 * Export all orders as a clean CSV spreadsheet report to Google Drive.
 */
export const exportOrdersCsvToGoogleDrive = async (orders: Order[]): Promise<DriveFileInfo> => {
  const folderId = await getOrCreateSeafoodFolder();

  const headers = ['Order ID', 'Date', 'Customer Name', 'Phone', 'Email', 'City', 'Address', 'Delivery Slot', 'Items Count', 'Subtotal (Rs)', 'Delivery Fee (Rs)', 'Total (Rs)', 'Status'];
  const rows = orders.map(o => [
    `"${o.id}"`,
    `"${o.createdAt}"`,
    `"${(o.customerName || '').replace(/"/g, '""')}"`,
    `"${o.customerPhone}"`,
    `"${o.customerEmail}"`,
    `"${o.city}"`,
    `"${(o.address || '').replace(/"/g, '""')}"`,
    `"${o.deliverySlot}"`,
    o.items?.length || 0,
    o.subtotal,
    o.deliveryFee,
    o.totalAmount,
    `"${o.orderStatus || 'Confirmed'}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const dateStr = new Date().toISOString().split('T')[0];
  const fileName = `GVD_Seafood_Orders_Export_${dateStr}.csv`;

  return await uploadFileToDrive({
    name: fileName,
    mimeType: 'text/csv',
    content: csvContent,
    folderId
  });
};
