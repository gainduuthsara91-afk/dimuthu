import { SeafoodProduct } from '../types/seafood';

export const DAILY_CATCH_PRODUCTS: SeafoodProduct[] = [
  {
    id: 'yellowfin-tuna-sashimi',
    name: 'Yellowfin Tuna Loin',
    scientificName: 'Thunnus albacares',
    category: 'tuna',
    pricePerKg: 1900.00,
    minWeightKg: 0.5,
    image: '/src/assets/images/catch_yellowfin_tuna_1792667467257.jpg',
    badge: 'Rs. 1,900 / kg · Pier Hand-Selected',
    origin: 'Mirissa Deep Offshore Basin',
    harvestMethod: 'Single-Hook Artisanal Handline',
    landedTime: 'Today 04:30 AM',
    grade: 'AAA+ Sushi & Sashimi Grade',
    flavorProfile: 'Clean, oceanic, mildly sweet with velvety butteriness',
    texture: 'Firm, dense ruby-red muscle with delicate melt-in-mouth fat',
    culinaryUses: ['Sashimi / Nigiri', 'Pan-Seared Rare', 'Poke Bowls', 'Carpaccio'],
    stockKg: 18.5,
    prepOptions: [
      'Sashimi-Grade Block (Sushi Ready)',
      'Prime Steaks (Center-Cut)',
      'Skin-on Fillets (Boneless)',
      'Whole (Cleaned, Scaled & Gutted)'
    ],
    sustainabilityRating: 'MSC Certified Responsible Handline',
    description: 'Harvested at dawn by local Mirissa master fishermen. Chilled instantly in slurry sea-ice directly on board to lock in pristine color, ruby translucence, and clean oceanic flavor.'
  },
  {
    id: 'thalapath-sailfish',
    name: 'Indo-Pacific Sailfish [Thalapath]',
    scientificName: 'Istiophorus platypterus',
    category: 'tuna',
    pricePerKg: 2500.00,
    minWeightKg: 0.8,
    image: '/src/assets/images/catch_thalapath_sailfish_1792685612218.jpg',
    badge: 'Rs. 2,500 / kg · Sri Lankan Favorite',
    origin: 'Mirissa Deep Offshore Trench',
    harvestMethod: 'Single-Hook Pelagic Handline',
    landedTime: 'Today 04:45 AM',
    grade: 'AAA+ Prime Steak & Curry Grade',
    flavorProfile: 'Meaty, rich, succulent with clean oceanic sweetness and firm bite',
    texture: 'Exceptionally firm, dense, boneless meat flakes that retain juiciness during cooking',
    culinaryUses: [
      'Authentic Thalapath Miris Malu Curry',
      'Thalapath Goraka Ambul Thiyal',
      'Charcoal Grilled Pepper Steaks',
      'Pan-Seared Garlic Butter Steaks'
    ],
    stockKg: 22.0,
    prepOptions: [
      'Prime Steaks (Center-Cut)',
      'Skin-on Fillets (Boneless)',
      'Whole (Cleaned, Scaled & Gutted)'
    ],
    sustainabilityRating: 'Selective Deep-Water Line Catch',
    description: 'The undisputed king of Sri Lankan fish curries. Freshly landed Thalapath features magnificent iridescent silver flanks, dense boneless pinkish meat, and incredible flavor. Hand-sliced into thick, meaty center-cut steaks that absorb rich spices without breaking apart.'
  },
  {
    id: 'king-fish-tora',
    name: 'King Fish [Tora]',
    scientificName: 'Scomberomorus commerson',
    category: 'tuna',
    pricePerKg: 2400.00,
    minWeightKg: 0.8,
    image: '/src/assets/images/catch_king_fish_tora_1792815513840.jpg',
    badge: 'Rs. 2,400 / kg · Prized Thora',
    origin: 'Mirissa Coastal Deep Waters',
    harvestMethod: 'Artisanal Pelagic Drift Line & Hook',
    landedTime: 'Today 05:10 AM',
    grade: 'Grade-A Prime Round Steaks',
    flavorProfile: 'Rich, savory, pristine oceanic umami with delicate natural sweetness',
    texture: 'Firm, dense, succulent white-pink flakes that fry to golden perfection',
    culinaryUses: [
      'Sri Lankan Spicy Thora Malu Miris Curry',
      'Crispy Turmeric Pepper Fried Steaks',
      'Thora Fish Cutlets & Pastries',
      'Charcoal Grilled King Fish Steaks'
    ],
    stockKg: 20.0,
    prepOptions: [
      'Prime Steaks (Center-Cut)',
      'Skin-on Fillets (Boneless)',
      'Whole (Cleaned, Scaled & Gutted)'
    ],
    sustainabilityRating: 'Selective Day-Boat Line Catch',
    description: 'The premier choice across Sri Lanka for celebrations and luxury dining. Freshly landed Thora (King Fish) features distinctive iridescent barred flanks, dense boneless meat, and remarkable flavor. Hand-sliced into thick, succulent steaks.'
  },
  {
    id: 'wild-red-crab',
    name: 'Red Crab',
    scientificName: 'Charybdis feriata / Portunidae',
    category: 'crabs',
    pricePerKg: 2500.00,
    minWeightKg: 0.8,
    image: '/src/assets/images/catch_wild_red_crab_1792815530043.jpg',
    badge: 'Rs. 2,500 / kg · Live Catch',
    origin: 'Southern Deep Coral Reefs & Palk Strait',
    harvestMethod: 'Traditional Baited Crab Pots',
    landedTime: 'Today 04:15 AM',
    grade: 'Grade-A Heavy Packed Meat',
    flavorProfile: 'Exceptionally sweet, tender, and deeply savory claw & body meat',
    texture: 'Silky, tender meat strands packed with rich coral crab roe umami',
    culinaryUses: [
      'Spicy Jaffna Style Red Crab Curry',
      'Chili Garlic Butter Wok Crab',
      'Black Pepper Tamarind Crab',
      'Steamed Crab with Ginger Lime Dip'
    ],
    stockKg: 15.0,
    prepOptions: [
      'Live / Shell-on Chilled',
      'Whole (Cleaned, Scaled & Gutted)'
    ],
    sustainabilityRating: 'Regulated Mature Shell Harvest',
    description: 'Renowned for striking crimson-mottled shells and dense, sweet claw meat. Hand-inspected for maximum heft and fullness. Delivered live and chilled in sea-ice packing directly to your kitchen.'
  },
  {
    id: 'barramundi-sea-bass',
    name: 'Ocean Barramundi (Modha)',
    scientificName: 'Lates calcarifer',
    category: 'reef-fish',
    pricePerKg: 2500.00,
    minWeightKg: 0.8,
    image: '/src/assets/images/hero_fresh_catch_1792667466212.jpg',
    badge: 'Rs. 2,500 / kg · Crispy Skin Ideal',
    origin: 'Galle Coastal Estuary Waters',
    harvestMethod: 'Selective Day-Tangle Nets',
    landedTime: 'Today 05:40 AM',
    grade: 'Chef Selection Grade A',
    flavorProfile: 'Buttery, clean, mild, with zero muddy notes',
    texture: 'Succulent, medium-firm flake with crispy-searing skin',
    culinaryUses: ['Pan-Crisped Skin Fillet', 'Herb Butter Poached', 'Thai Lime & Lemongrass Steam', 'Charcoal Whole Roast'],
    stockKg: 16.0,
    prepOptions: [
      'Skin-on Fillets (Boneless)',
      'Prime Steaks (Center-Cut)',
      'Whole (Cleaned, Scaled & Gutted)'
    ],
    sustainabilityRating: 'Coastal Artisanal Fishery',
    description: 'Prized Sri Lankan Modha caught in clear ocean brackish currents. Hand-descaled and cut into thick center portions ideal for achieving restaurant-crisp skin.'
  },
  {
    id: 'white-mullet-gal-malu',
    name: 'White Mullet [Gal Malu]',
    scientificName: 'Mugil cephalus / Liza vaigiensis',
    category: 'reef-fish',
    pricePerKg: 1800.00,
    minWeightKg: 0.5,
    image: '/src/assets/images/catch_white_mullet_gal_malu_1792814687095.jpg',
    badge: 'Rs. 1,800 / kg · Gal Malu',
    origin: 'Mirissa Coral Reefs & Coastal Estuaries',
    harvestMethod: 'Artisanal Day-Boat Hook & Shallow Net',
    landedTime: 'Today 05:45 AM',
    grade: 'Grade-A Fresh White Table Fish',
    flavorProfile: 'Clean, sweet, tender, and subtly rich with delicate natural sea oils',
    texture: 'Moist, succulent white meat with fine flakes that retain moisture when fried or curried',
    culinaryUses: [
      'Sri Lankan Spicy Gal Malu Miris Curry',
      'Crispy Turmeric & Pepper Shallow Pan Fry',
      'Herb Baked in Banana Leaf',
      'Kirikodu Coconut Milk Mild Stew'
    ],
    stockKg: 16.0,
    prepOptions: [
      'Whole (Cleaned, Scaled & Gutted)',
      'Prime Steaks (Center-Cut)',
      'Skin-on Fillets (Boneless)'
    ],
    sustainabilityRating: 'Coastal Artisanal Handline',
    description: 'A beloved Sri Lankan coastal favorite, known locally as Gal Malu (White Mullet). Features glistening iridescent scales, firm sweet white meat, and rich flavor. Sold at Rs. 1,800 per kg, scaled, cleaned, and cut fresh to your exact preference.'
  },
  {
    id: 'sappara-fish',
    name: 'Fresh Sappara',
    scientificName: 'Xiphias gladius / Istiophoridae',
    category: 'reef-fish',
    pricePerKg: 1600.00,
    minWeightKg: 0.8,
    image: '/assets/aistudio/maxresdefault_a028296b.jpg',
    badge: 'Headless',
    origin: 'Mirissa Coastal Deep Waters',
    harvestMethod: 'Artisanal Pelagic Drift Handline',
    landedTime: 'Today 05:20 AM',
    grade: 'Grade-A Headless Dressed Steak Grade',
    flavorProfile: 'Rich, savory, clean oceanic umami with deep natural flavors',
    texture: 'Dense, meaty boneless steak flesh that holds firm during currying, grilling or frying',
    culinaryUses: ['Sri Lankan Spicy Fish Curry', 'Turmeric Pepper Fried Steaks', 'Ambul Thiyal', 'Charcoal BBQ Steaks'],
    stockKg: 18.0,
    prepOptions: [
      'Prime Steaks (Center-Cut, Headless)',
      'Headless Cleaned (Gutted)',
      'Skin-on Fillets (Boneless, Headless)'
    ],
    sustainabilityRating: 'Selective Day-Boat Line Catch',
    description: 'Landed fresh at Mirissa Pier and sold strictly headless (zero head or bill weight). Every kilogram is 100% prime edible flesh portioned into thick, hearty steaks or boneless fillets. Perfect for authentic Sri Lankan spicy fish curries, ambul thiyal, or crisp pan-frying.'
  },
  {
    id: 'frozen-cuttlefish-cone',
    name: 'Frozen Cuttle Fish Cone',
    scientificName: 'Sepia pharaonis / Loliginidae',
    category: 'reef-fish',
    pricePerKg: 1700.00,
    minWeightKg: 0.5,
    image: '/src/assets/images/catch_cuttlefish_cones_1792815546203.jpg',
    badge: 'Rs. 1,700 / kg · Cleaned Cones',
    origin: 'Mirissa Ocean Deep Waters',
    harvestMethod: 'Sub-Zero Blast Frozen Day Catch',
    landedTime: 'Blast Chilled -18°C',
    grade: 'Export Grade Tender Cleaned Tubes',
    flavorProfile: 'Delicate, mildly sweet, clean oceanic flavor with tender bite',
    texture: 'Plump, snowy-white, velvety meat that turns incredibly tender and crispy',
    culinaryUses: [
      'Hot Butter Cuttlefish (Sri Lankan HBC)',
      'Spicy Cuttlefish Devil with Leeks & Onion',
      'Crispy Calamari Rings with Garlic Dip',
      'Sri Lankan Black Roast Cuttlefish Curry'
    ],
    stockKg: 25.0,
    prepOptions: [
      'Cleaned Cones (Whole Ready)',
      'Ring Cut (Calamari / HBC Style)',
      'Skin-on Fillets (Boneless)'
    ],
    sustainabilityRating: 'Ethical Pelagic Fishery',
    description: 'Tender, snowy-white cleaned cuttlefish cones (tubes), skinless and gutted for immediate cooking. Quick-frozen at sub-zero temperatures immediately after harvest to preserve springy texture and sweetness. Ideal for Sri Lankan Hot Butter Cuttlefish (HBC) and devilled cuttlefish.'
  },
  {
    id: 'lakmal-grand-seafood-box',
    name: "G.V.D.Lakmal Chef's Grand Feast Box",
    scientificName: 'Artisan Ocean Selection',
    category: 'boxes',
    pricePerKg: 12500.00,
    minWeightKg: 1.0,
    image: '/src/assets/images/cold_chain_delivery_1792667469630.jpg',
    badge: 'Curated Bundle · Save 18%',
    origin: 'Multi-Harbor Dawn Landing',
    harvestMethod: 'Various Ethical Artisan Methods',
    landedTime: 'Packed Fresh Today',
    grade: 'Export First-Grade Collection',
    flavorProfile: 'A complete symphony of oceanic flavors from sashimi tuna to sweet crab',
    texture: 'Varied cuts vacuum sealed with custom herb rubs',
    culinaryUses: ['Weekend Family Seafood BBQ', 'Gourmet Dinner Parties', 'Luxury Coastal Gifting'],
    stockKg: 8.0,
    prepOptions: [
      'Skin-on Fillets (Boneless)',
      'Prime Steaks (Center-Cut)'
    ],
    sustainabilityRating: '100% Traceable Fleet Catch',
    description: 'Includes 1kg Yellowfin Tuna Sashimi Loins, 1kg King Fish (Thora) Steaks, 2 Whole Red Crabs, and 800g White Mullet (Gal Malu) Fillets, packed with eco-sea ice in our wooden gift box with sea salt and marinade.'
  }
];

export const FLEET_INFO = {
  founder: 'G.V.D. Lakmal',
  foundingYear: '2008',
  harborBases: ['Mirissa International Fishery Harbor', 'Negombo Pier', 'Galle Fort Anchorage'],
  vessels: [
    { name: 'Oruwa Dawn Star', captain: 'Lakmal & Crew', type: 'Deep Sea Handliner', spec: 'GPS Slurry-Chamber' },
    { name: 'Ocean Sapphire II', captain: 'Ruwan Kumara', type: 'Day Netter', spec: 'Aerated Live Tank' },
    { name: 'Mirissa Queen', captain: 'D. Priyantha', type: 'Pelagic Longliner', spec: 'Sub-Zero Blast Chilled' }
  ],
  certifications: [
    'Export Quality Inspection Board Certified',
    'ISO 22000 Food Safety & HACCP Compliant Cold Chain',
    'Marine Stewardship Traceable Harvest Protocols',
    'Zero Chemical Preservatives or Formalin Guarantee'
  ]
};

export const REVIEWS = [
  {
    author: 'Chef Julien Laurent',
    role: 'Executive Chef',
    organization: 'The Fort Pavilion Hotel & Dining',
    quote: 'The yellowfin tuna loin delivered by G.V.D.Lakmal Seafood is the truest sashimi quality on the island. Delivered at 1.8°C directly to our kitchen door before our lunchtime rush.',
    rating: 5,
    verifiedOrder: 'Yellowfin Tuna Loin (AAA+ Sashimi)'
  },
  {
    author: 'Nimalka Samarasinghe',
    role: 'Private Yacht Hospitality Host',
    organization: 'Southern Coast Charters',
    quote: 'The King fish (Thora) steaks and red crabs arrived fresh and chilled in pristine sea-ice thermal boxes. Zero odor, unmatched sweetness. Our guests were mesmerized.',
    rating: 5,
    verifiedOrder: 'King Fish & Red Crab Feast'
  },
  {
    author: 'Dr. Aruna Perera',
    role: 'Home Epicure & Resident',
    organization: 'Colombo 07',
    quote: 'Ordering whole ocean barramundi cleaned and filleted to perfection makes home dining effortless. The secure card payment and instant receipt gave us complete peace of mind.',
    rating: 5,
    verifiedOrder: 'Ocean Barramundi (Boneless Fillets)'
  }
];
