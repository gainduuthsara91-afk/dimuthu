/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { DailyCatchGallery } from './components/DailyCatchGallery';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ColdChainSection } from './components/ColdChainSection';
import { FleetStory } from './components/FleetStory';
import { Reviews } from './components/Reviews';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { WholesaleModal } from './components/WholesaleModal';
import { OwnerInboxModal } from './components/OwnerInboxModal';
import { SecurityCenterModal } from './components/SecurityCenterModal';
import { WhatsAppButton } from './components/WhatsAppButton';
import { Footer } from './components/Footer';
import { DAILY_CATCH_PRODUCTS } from './data/seafoodData';
import { CartItem, Order, SeafoodProduct } from './types/seafood';

export default function App() {
  // Cart state persisted to localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('gvd_lakmal_cart');
      return saved ? JSON.parse(saved) : [
        {
          id: 'default-cart-item-1',
          productId: 'yellowfin-tuna-sashimi',
          product: DAILY_CATCH_PRODUCTS[0],
          selectedPrep: 'Sashimi-Grade Block (Sushi Ready)',
          weightKg: 1.0,
          quantity: 1,
          totalPrice: 1900.00
        }
      ];
    } catch {
      return [];
    }
  });

  // Recent orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('gvd_lakmal_orders');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [
      {
        id: 'GVD-84920',
        createdAt: '05:30 AM, Today',
        items: [
          {
            id: 'mock-1',
            productId: 'yellowfin-tuna-sashimi',
            product: DAILY_CATCH_PRODUCTS[0],
            selectedPrep: 'Sashimi-Grade Block (Sushi Ready)',
            weightKg: 1.5,
            quantity: 1,
            totalPrice: 2850.00
          },
          {
            id: 'mock-2',
            productId: 'king-fish-tora',
            product: DAILY_CATCH_PRODUCTS[2],
            selectedPrep: 'Prime Steaks (Center-Cut)',
            weightKg: 1.0,
            quantity: 1,
            totalPrice: 2400.00
          }
        ],
        subtotal: 5250.00,
        deliveryFee: 0,
        packagingFee: 0,
        totalAmount: 5250.00,
        customerName: 'Executive Chef Laurent',
        customerPhone: '+94 77 982 1100',
        customerEmail: 'chef.laurent@fortpavilion.lk',
        address: 'Church Cross Street, Galle Fort',
        city: 'Galle',
        postalCode: '80000',
        deliverySlot: 'Morning Window: 07:00 AM – 11:00 AM',
        deliveryInstructions: 'Kitchen service entrance at rear gate',
        packagingType: 'signature-ice',
        paymentMethod: 'card',
        paymentStatus: 'paid',
        orderStatus: 'in-transit',
        temperatureLog: '1.7°C Nominal Sea-Ice'
      }
    ];
  });

  // Modal / Drawer visibility
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTrackerOpen, setIsTrackerOpen] = useState(false);
  const [isWholesaleOpen, setIsWholesaleOpen] = useState(false);
  const [isOwnerInboxOpen, setIsOwnerInboxOpen] = useState(false);
  const [isSecurityOpen, setIsSecurityOpen] = useState(false);
  const [selectedProductForDetail, setSelectedProductForDetail] = useState<SeafoodProduct | null>(null);
  const [trackerOrderId, setTrackerOrderId] = useState<string>('GVD-84920');

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('gvd_lakmal_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('gvd_lakmal_orders', JSON.stringify(orders));
    } catch (e) {
      console.error(e);
    }
  }, [orders]);

  // Cart operations
  const handleAddToCart = (itemToAdd: Omit<CartItem, 'id' | 'totalPrice'>) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (item) =>
          item.productId === itemToAdd.productId &&
          item.selectedPrep === itemToAdd.selectedPrep &&
          item.weightKg === itemToAdd.weightKg
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += itemToAdd.quantity;
        return updated;
      }

      const newItem: CartItem = {
        ...itemToAdd,
        id: `${itemToAdd.productId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        totalPrice: itemToAdd.product.pricePerKg * itemToAdd.weightKg
      };

      return [...prev, newItem];
    });

    // Provide instant subtle feedback and give option to inspect bag
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== itemId));
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderPlaced = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    setCart([]); // Clear cart
    setTrackerOrderId(newOrder.id);
  };

  const handleOpenTrackerForOrder = (orderId: string) => {
    setTrackerOrderId(orderId);
    setIsTrackerOpen(true);
  };

  const handleScrollToCatch = () => {
    const el = document.getElementById('catch-gallery');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToColdChain = () => {
    const el = document.getElementById('cold-chain');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#07131F] text-slate-100 flex flex-col font-sans">
      
      {/* Header conforming strictly to Top Bar Contract */}
      <Header
        cart={cart}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenTracker={() => setIsTrackerOpen(true)}
        onOpenWholesale={() => setIsWholesaleOpen(true)}
        onOpenOwnerInbox={() => setIsOwnerInboxOpen(true)}
        onOpenSecurity={() => setIsSecurityOpen(true)}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onScrollToCatch={handleScrollToCatch}
          onScrollToColdChain={handleScrollToColdChain}
        />

        {/* Daily Catch Gallery */}
        <DailyCatchGallery
          products={DAILY_CATCH_PRODUCTS}
          onAddToCart={handleAddToCart}
          onOpenProductDetail={(prod) => setSelectedProductForDetail(prod)}
        />

        {/* Cold-Chain Process & Doorstep Delivery Assurance */}
        <ColdChainSection />

        {/* Fleet Heritage & Artisan Fishermen Story */}
        <FleetStory />

        {/* Chef & Customer Endorsements */}
        <Reviews />
      </main>

      {/* Footer */}
      <Footer
        onOpenTracker={() => setIsTrackerOpen(true)}
        onOpenWholesale={() => setIsWholesaleOpen(true)}
        onOpenSecurity={() => setIsSecurityOpen(true)}
      />

      {/* Modals & Drawers */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={handleProceedToCheckout}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        onOrderPlaced={handleOrderPlaced}
        onOpenTrackerForOrder={handleOpenTrackerForOrder}
      />

      {selectedProductForDetail && (
        <ProductDetailModal
          product={selectedProductForDetail}
          onClose={() => setSelectedProductForDetail(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      <OrderTrackerModal
        isOpen={isTrackerOpen}
        onClose={() => setIsTrackerOpen(false)}
        recentOrders={orders}
        initialOrderId={trackerOrderId}
      />

      <WholesaleModal
        isOpen={isWholesaleOpen}
        onClose={() => setIsWholesaleOpen(false)}
      />

      <OwnerInboxModal
        isOpen={isOwnerInboxOpen}
        onClose={() => setIsOwnerInboxOpen(false)}
        orders={orders}
        onOpenSecurity={() => setIsSecurityOpen(true)}
      />

      <SecurityCenterModal
        isOpen={isSecurityOpen}
        onClose={() => setIsSecurityOpen(false)}
      />

      {/* Floating WhatsApp Contact Button (077 878 8454) */}
      <WhatsAppButton />

    </div>
  );
}
