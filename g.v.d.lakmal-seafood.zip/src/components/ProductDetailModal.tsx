import React, { useState } from 'react';
import { X, ShieldCheck, ThermometerSnowflake, Compass, ChefHat, Check, Plus, Minus, AlertCircle, MessageCircle } from 'lucide-react';
import { SeafoodProduct, PrepOption, CartItem } from '../types/seafood';
import { formatPrice } from '../utils/format';

interface ProductDetailModalProps {
  product: SeafoodProduct | null;
  onClose: () => void;
  onAddToCart: (item: Omit<CartItem, 'id' | 'totalPrice'>) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart
}) => {
  const [selectedWeight, setSelectedWeight] = useState<number>(() => product ? product.minWeightKg : 1);
  const [selectedPrep, setSelectedPrep] = useState<PrepOption | undefined>(() => product ? product.prepOptions[0] : undefined);
  const [isAdded, setIsAdded] = useState(false);

  if (!product || !selectedPrep) return null;

  const totalPrice = product.pricePerKg * selectedWeight;

  const handleAdd = () => {
    onAddToCart({
      productId: product.id,
      product,
      selectedPrep,
      weightKg: selectedWeight,
      quantity: 1
    });
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-3xl rounded-2xl bg-[#091726] border border-slate-800 shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-slate-950/70 text-slate-400 hover:text-white hover:bg-slate-900 border border-slate-800 transition-colors cursor-pointer"
          aria-label="Close inspection modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Left Column: Imagery & Visual Inspection */}
          <div className="relative aspect-[4/3] md:aspect-auto h-64 md:h-full bg-slate-950 overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#091726] via-transparent to-transparent md:hidden" />

            <div className="absolute bottom-4 left-4 right-4 bg-slate-950/90 backdrop-blur-md p-3 rounded-xl border border-slate-800/80">
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Harbor Inspection Certified</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Landed: <strong className="text-white">{product.landedTime}</strong> · Inspected at Mirissa Pier Cold Station.
              </p>
            </div>
          </div>

          {/* Right Column: Culinary Details & Buying Module */}
          <div className="p-6 flex flex-col justify-between">
            <div>
              {/* Provenance Kicker */}
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400 mb-1.5 flex-wrap">
                <span>{product.origin}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-amber-400">{product.grade}</span>
              </div>

              <h2 className="font-serif text-2xl font-semibold text-white">
                {product.name}
              </h2>
              <p className="text-xs text-slate-400 italic mb-4">
                {product.scientificName}
              </p>

              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                {product.description}
              </p>

              {/* Sensory & Flavor Profile */}
              <div className="space-y-2 py-3 border-y border-slate-800/80 text-xs">
                <div className="flex items-start gap-2">
                  <span className="text-slate-400 font-medium w-24 shrink-0">Flavor Profile:</span>
                  <span className="text-slate-200">{product.flavorProfile}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-400 font-medium w-24 shrink-0">Flesh Texture:</span>
                  <span className="text-slate-200">{product.texture}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-400 font-medium w-24 shrink-0">Harvest Method:</span>
                  <span className="text-slate-200">{product.harvestMethod}</span>
                </div>
              </div>

              {/* Recommended Culinary Pairings */}
              <div className="mt-4">
                <span className="text-[11px] font-semibold tracking-wider uppercase text-slate-400 flex items-center gap-1.5 mb-2">
                  <ChefHat className="w-3.5 h-3.5 text-amber-400" />
                  Recommended Culinary Preparations
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {product.culinaryUses.map((use) => (
                    <span
                      key={use}
                      className="text-xs text-slate-300 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded"
                    >
                      {use}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Sticky Purchase Control Section */}
            <div className="mt-6 pt-4 border-t border-slate-800 space-y-4">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1 font-medium">
                  Select Cutting & Prep Style:
                </label>
                <select
                  value={selectedPrep}
                  onChange={(e) => setSelectedPrep(e.target.value as PrepOption)}
                  aria-label="Cutting and prep style"
                  className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  {product.prepOptions.map((prep) => (
                    <option key={prep} value={prep}>
                      {prep}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5 font-medium">
                  <span className="flex items-center gap-1.5">
                    <span>Select Quantity / Weight:</span>
                    <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold tracking-wider">
                      Unlimited
                    </span>
                  </span>
                  <span className="font-mono text-slate-300">{formatPrice(product.pricePerKg)} / kg</span>
                </div>

                {/* Quick Presets */}
                <div className="grid grid-cols-6 gap-1 mb-2">
                  {[0.5, 1.0, 2.0, 5.0, 10.0, 25.0].map((w) => (
                    <button
                      key={w}
                      type="button"
                      onClick={() => setSelectedWeight(w)}
                      className={`py-1.5 text-xs font-mono rounded border transition-colors cursor-pointer ${
                        selectedWeight === w
                          ? 'bg-amber-500 text-slate-950 font-bold border-amber-500 shadow-sm'
                          : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {w}kg
                    </button>
                  ))}
                </div>

                {/* Custom Direct Input & Stepper */}
                <div className="flex items-center justify-between bg-slate-950/90 rounded-lg border border-slate-800 p-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      const newW = Math.max(0.5, Math.round((selectedWeight - (selectedWeight > 5 ? 1 : 0.5)) * 10) / 10);
                      setSelectedWeight(newW);
                    }}
                    className="w-8 h-8 flex items-center justify-center rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="Decrease weight"
                  >
                    <Minus className="w-4 h-4" />
                  </button>

                  <div className="flex items-center justify-center gap-1.5 flex-1 px-3">
                    <span className="text-[11px] text-slate-500">Weight:</span>
                    <input
                      type="number"
                      min="0.1"
                      step="0.5"
                      value={selectedWeight}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        if (!isNaN(val) && val > 0) {
                          setSelectedWeight(val);
                        }
                      }}
                      className="w-24 text-center font-mono text-base font-bold text-amber-300 bg-transparent border-b border-slate-700 focus:border-amber-400 focus:outline-none"
                    />
                    <span className="text-xs font-mono text-slate-400">kg</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const newW = Math.round((selectedWeight + (selectedWeight >= 5 ? 1 : 0.5)) * 10) / 10;
                      setSelectedWeight(newW);
                    }}
                    className="w-8 h-8 flex items-center justify-center rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="Increase weight (unlimited)"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Subtotal & Buy Button */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block">
                    Calculated Total
                  </span>
                  <span className="font-mono text-2xl font-bold text-white tabular-nums">
                    {formatPrice(totalPrice)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/94778788454?text=${encodeURIComponent(`Hello G.V.D.Lakmal Seafood, I am inquiring about ${product.name} (${selectedWeight}kg, ${selectedPrep}).`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-3 rounded-lg border border-emerald-500/50 bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                    title="Inquire about this catch on WhatsApp: 077 878 8454"
                  >
                    <MessageCircle className="w-4 h-4 fill-emerald-400 text-slate-950" />
                    <span>WhatsApp</span>
                  </a>

                  <button
                    onClick={handleAdd}
                    className={`flex-1 sm:flex-initial px-5 py-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                      isAdded
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/15'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check className="w-4 h-4 stroke-[2.5]" />
                        <span>Added to Bag</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 stroke-[2.2]" />
                        <span>Add to Fresh Bag</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
