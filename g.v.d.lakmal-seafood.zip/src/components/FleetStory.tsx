import React from 'react';
import { Anchor, ShieldCheck, Compass, HeartHandshake } from 'lucide-react';
import { FLEET_INFO } from '../data/seafoodData';

export const FleetStory: React.FC = () => {
  return (
    <section id="fleet-story" className="py-20 border-t border-slate-800/80 bg-[#07131F] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-amber-400 mb-2">
            <span>Maritime Heritage</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Est. 2008 Mirissa Pier</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-white [text-wrap:balance]">
            Our fleet, artisan ethics & harbor stewardship.
          </h2>
          <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
            Founded by <strong className="text-white">G.V.D. Lakmal</strong> over sixteen years ago, our company was built on a simple premise: fishermen should be fairly compensated for pristine quality, and seafood lovers deserve fish that was swimming in ocean currents merely hours prior.
          </p>
        </div>

        {/* 3 Vessels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {FLEET_INFO.vessels.map((vessel) => (
            <div
              key={vessel.name}
              className="p-5 rounded-2xl border border-slate-800 bg-[#091726] transition-all hover:border-slate-700"
            >
              <div className="flex items-center justify-between text-xs font-mono text-amber-400 mb-2">
                <span>Vessel Registry</span>
                <Compass className="w-4 h-4 text-slate-500" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-white">
                {vessel.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Command: {vessel.captain}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-800 text-xs space-y-1.5 text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-500">Method:</span>
                  <span className="font-medium text-slate-200">{vessel.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Preservation:</span>
                  <span className="font-mono text-sky-300 text-[11px]">{vessel.spec}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Four Core Ethical Commitments */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-6 rounded-2xl border border-slate-800 bg-[#06111D]">
          <div>
            <div className="text-amber-400 text-sm font-semibold mb-1 flex items-center gap-1.5">
              <Anchor className="w-4 h-4" />
              <span>Day-Boat Handline</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              We prohibit industrial bottom trawling. Our catches come from targeted single-hook handlines and selective day nets that leave coral reefs undamaged.
            </p>
          </div>

          <div>
            <div className="text-amber-400 text-sm font-semibold mb-1 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Zero Chemical Additives</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              No formalin, no ammonia glaze, no water-weight injections. Only pure deep sea-ice and crystal salinity keep the meat firm and translucent.
            </p>
          </div>

          <div>
            <div className="text-amber-400 text-sm font-semibold mb-1 flex items-center gap-1.5">
              <HeartHandshake className="w-4 h-4" />
              <span>Fair Pier Compensation</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              We pay our coastal fishermen a 25% premium above open wholesale auctions in exchange for gentle handling, bleeding at sea, and immediate slush-icing.
            </p>
          </div>

          <div>
            <div className="text-amber-400 text-sm font-semibold mb-1 flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-sky-400" />
              <span>100% Catch Traceability</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every parcel shipped features the boat name, landing dock time, and GPS harvest zone code printed clearly on the cold-chain receipt.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
