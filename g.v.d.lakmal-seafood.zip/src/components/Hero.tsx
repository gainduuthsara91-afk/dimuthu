import React from 'react';
import { ArrowDown, ShieldCheck, ThermometerSnowflake, Compass, Sparkles } from 'lucide-react';

interface HeroProps {
  onScrollToCatch: () => void;
  onScrollToColdChain: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToCatch, onScrollToColdChain }) => {
  return (
    <section className="relative pt-6 pb-14 overflow-hidden">
      {/* Background radial atmosphere */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-blue-900/20 via-transparent to-transparent pointer-events-none blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* 2-Column Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          
          {/* Left Column: Editorial & Story */}
          <div className="lg:col-span-6 flex flex-col justify-center py-4 lg:py-8">
            
            {/* Editorial Kicker - Unboxed Clean Text */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-amber-400 mb-4">
              <span>Artisan Sea Purveyor</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Direct Dawn Landings</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Zero Preservatives</span>
            </div>

            {/* Display Headline with text-wrap balance */}
            <h1 className="font-serif text-3xl sm:text-5xl lg:text-5.5xl font-semibold tracking-tight text-white leading-[1.12] [text-wrap:balance] mb-6">
              Ocean harvest, hand-selected at dawn.
            </h1>

            {/* Prose description */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl mb-8">
              <strong className="text-white font-medium">G.V.D.Lakmal Seafood</strong> bridges the gap between Sri Lanka’s southern coastal day-boats and your dining table. Yellowfin tuna, King fish (Tora), red crabs, and pristine reef fish harvested sustainably and dispatched within hours in unbroken <span className="text-amber-300 font-medium">0°C–2°C sub-zero sea ice</span>.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-8">
              <button
                onClick={onScrollToCatch}
                className="px-6 py-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-semibold text-sm transition-all shadow-xl shadow-amber-500/15 flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
              >
                <span>Explore Today’s Fresh Catch</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              <button
                onClick={onScrollToColdChain}
                className="px-6 py-3.5 rounded-lg border border-slate-700 bg-slate-900/60 hover:bg-slate-800 text-slate-200 font-medium text-sm transition-all hover:border-slate-500 cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-2"
              >
                <ThermometerSnowflake className="w-4 h-4 text-sky-400" />
                <span>Cold-Chain Assurance</span>
              </button>
            </div>

            {/* Trust Markers - Quiet text with separators */}
            <div className="flex items-center gap-3 text-xs text-slate-400 pt-4 border-t border-slate-800/80">
              <div className="flex items-center gap-1.5 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>HACCP & Export Certified</span>
              </div>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span>100% Traceable Day-Boat Fishing</span>
              <span className="text-slate-600 hidden sm:inline" aria-hidden="true">·</span>
              <span className="hidden sm:inline">Cleaned & Portioned to Order</span>
            </div>

          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-6 relative min-h-[380px] lg:min-h-full">
            <div className="relative h-full w-full rounded-2xl overflow-hidden border border-slate-800/90 shadow-2xl bg-slate-900 group">
              <img
                src="/src/assets/images/hero_fresh_catch_1792667466212.jpg"
                alt="Abundant fresh seafood display on crushed ice by G.V.D.Lakmal Seafood"
                className="w-full h-full object-cover object-center group-hover:scale-[1.02] transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              
              {/* Gradient Scrim for legible text overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#07131F] via-[#07131F]/30 to-transparent pointer-events-none" />

              {/* Live Harbor Landing Dispatch Note in lower overlay */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#0B1A2C]/90 backdrop-blur-md border border-slate-700/70 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-0.5">
                    <Compass className="w-3.5 h-3.5" />
                    <span>Harbor Report · Mirissa & Negombo</span>
                  </div>
                  <p className="text-sm text-slate-200 font-medium">
                    Dawn harvest docked at 04:30 AM · Slurry ice logged at 1.4°C
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block">Dispatch Status</span>
                  <span className="text-xs font-semibold text-emerald-400">Taking Orders</span>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Full-Width 4-Column KPI Strip */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 border-y border-slate-800/80 py-6">
          <div className="flex flex-col">
            <span className="font-mono text-2xl sm:text-3xl font-bold text-white tabular-nums">04:30 AM</span>
            <span className="text-xs font-medium text-slate-400 mt-1">Harbor Pier Docking</span>
            <span className="text-[11px] text-slate-500">Selected at dawn break</span>
          </div>

          <div className="flex flex-col">
            <span className="font-mono text-2xl sm:text-3xl font-bold text-sky-400 tabular-nums">0°C – 2°C</span>
            <span className="text-xs font-medium text-slate-400 mt-1">Controlled Sea-Ice Chain</span>
            <span className="text-[11px] text-slate-500">Never frozen, always chilled</span>
          </div>

          <div className="flex flex-col">
            <span className="font-mono text-2xl sm:text-3xl font-bold text-amber-400 tabular-nums">100%</span>
            <span className="text-xs font-medium text-slate-400 mt-1">Ocean Harvested</span>
            <span className="text-[11px] text-slate-500">Single-hook & artisan nets</span>
          </div>

          <div className="flex flex-col">
            <span className="font-mono text-2xl sm:text-3xl font-bold text-emerald-400 tabular-nums">&lt; 4 Hours</span>
            <span className="text-xs font-medium text-slate-400 mt-1">Harbor to Doorstep</span>
            <span className="text-[11px] text-slate-500">Same-day chilled courier</span>
          </div>
        </div>

      </div>
    </section>
  );
};
