import React, { useState } from 'react';
import { 
  X, Search, Truck, ThermometerSnowflake, ShieldCheck, 
  CheckCircle2, Clock, MapPin, RefreshCw, AlertCircle
} from 'lucide-react';
import { Order } from '../types/seafood';

interface OrderTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  recentOrders: Order[];
  initialOrderId?: string;
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  isOpen,
  onClose,
  recentOrders,
  initialOrderId
}) => {
  const defaultOrderId = initialOrderId || (recentOrders.length > 0 ? recentOrders[0].id : 'GVD-84920');
  const [searchId, setSearchId] = useState(defaultOrderId);
  const [activeOrder, setActiveOrder] = useState<Order | null>(() => {
    return recentOrders.find(o => o.id === defaultOrderId) || null;
  });

  // Simulator step for interactive testing
  const [simulatedStatusIndex, setSimulatedStatusIndex] = useState(2); // In transit

  const stages = [
    { title: 'Pier Catch Landed & Graded', time: '04:30 AM', note: 'Single-hook yellowfin tuna & tiger prawns logged on dock' },
    { title: 'Artisan Custom Fillet & Vacuum Pack', time: '05:15 AM', note: 'Hand-portioned, descaled & sea-ice slurry packed' },
    { title: 'Refrigerated Cold-Van In Transit', time: '06:00 AM', note: 'Chamber temperature locked at 1.7°C' },
    { title: 'Out for Doorstep Handover', time: 'In Progress', note: 'Courier arriving in thermal delivery box' },
    { title: 'Delivered Fresh & Temperature Verified', time: 'Pending', note: 'Signed & checked at customer kitchen' }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const found = recentOrders.find(o => o.id.toLowerCase() === searchId.trim().toLowerCase());
    if (found) {
      setActiveOrder(found);
    } else {
      // Create preview state for mock ID
      setActiveOrder({
        id: searchId.toUpperCase(),
        createdAt: 'Today, 04:45 AM',
        items: [],
        subtotal: 98.50,
        deliveryFee: 0,
        packagingFee: 0,
        totalAmount: 98.50,
        customerName: 'Valued Seafood Patron',
        customerPhone: '+94 77 ••• ••••',
        customerEmail: 'patron@domain.com',
        address: '42 Marine Drive, Colombo',
        city: 'Colombo 03',
        postalCode: '00300',
        deliverySlot: 'Morning Window (07:00 – 11:00 AM)',
        packagingType: 'signature-ice',
        paymentMethod: 'card',
        paymentStatus: 'paid',
        orderStatus: 'in-transit',
        temperatureLog: '1.7°C Nominal Chilled'
      });
    }
  };

  const handleAdvanceSimulation = () => {
    setSimulatedStatusIndex((prev) => (prev + 1) % stages.length);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-2xl rounded-2xl bg-[#091726] border border-slate-800 shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-[#06111D]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white p-1 border border-slate-700/80 shrink-0 overflow-hidden shadow-sm">
              <img
                src="/assets/aistudio/Modern_Navy_Seafood_Logo_fceeff00.png"
                alt="G.V.D.Lakmal Seafood Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h2 className="font-serif text-lg font-semibold text-white">
                Live Cold-Chain Order Tracker
              </h2>
              <p className="text-[11px] text-slate-400">
                G.V.D.Lakmal Pier Dispatch & Courier Telemetry
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close tracker modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          
          {/* Search Order Bar */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Enter Order ID (e.g. GVD-84920)..."
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs font-mono bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors cursor-pointer"
            >
              Locate Catch
            </button>
          </form>

          {/* Active Order Telemetry Card */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/70">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block">Tracking Order</span>
                <span className="font-mono text-base font-bold text-amber-400">{searchId.toUpperCase()}</span>
              </div>

              {/* Digital Temperature Logger Badge */}
              <div className="flex items-center gap-2 bg-sky-950/50 border border-sky-800/80 px-3 py-1.5 rounded-lg text-xs font-mono">
                <ThermometerSnowflake className="w-4 h-4 text-sky-400 animate-pulse" />
                <div>
                  <span className="text-slate-400 text-[10px] block">Cold Chamber Sensor</span>
                  <span className="text-sky-300 font-bold">1.7°C (Nominal Sea-Ice)</span>
                </div>
              </div>
            </div>

            {/* Courier & Route Details */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px]">Origin Base</span>
                <span className="text-slate-200 font-medium">Mirissa Pier Cold Station</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Chilled Van</span>
                <span className="text-slate-200 font-mono">WP-CA-4029 (Unit #03)</span>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <span className="text-slate-500 block text-[10px]">Driver & Logistics</span>
                <span className="text-slate-200">Sunil Perera (Cold-Chain Cert)</span>
              </div>
            </div>
          </div>

          {/* Progress Timeline */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Freshness Journey Timeline
              </h3>
              <button
                onClick={handleAdvanceSimulation}
                className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium cursor-pointer"
                title="Cycle through delivery stages to test the tracker"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Simulate Next Phase</span>
              </button>
            </div>

            <div className="space-y-4 relative pl-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
              {stages.map((stage, idx) => {
                const isCompleted = idx <= simulatedStatusIndex;
                const isCurrent = idx === simulatedStatusIndex;

                return (
                  <div key={stage.title} className="relative">
                    {/* Status Dot */}
                    <div
                      className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors ${
                        isCompleted
                          ? 'border-emerald-400 bg-emerald-950 text-emerald-400'
                          : 'border-slate-700 bg-slate-900 text-slate-600'
                      }`}
                    >
                      {isCompleted && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                    </div>

                    <div className="text-xs">
                      <div className="flex items-center justify-between">
                        <span className={`font-semibold ${isCurrent ? 'text-amber-300' : isCompleted ? 'text-white' : 'text-slate-500'}`}>
                          {stage.title}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">{stage.time}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {stage.note}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quality Reassurance Note */}
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p>
              Your delivery container includes an irreversible temperature threshold stamp. If core temperature exceeds 4°C at delivery, we replace or refund instantly.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};
