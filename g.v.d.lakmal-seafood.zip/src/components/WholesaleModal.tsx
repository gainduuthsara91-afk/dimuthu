import React, { useState } from 'react';
import { X, Building, CheckCircle2, Send, PhoneCall } from 'lucide-react';

interface WholesaleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WholesaleModal: React.FC<WholesaleModalProps> = ({ isOpen, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    businessName: '',
    contactPerson: '',
    phone: '',
    email: '',
    businessType: 'Fine Dining Restaurant',
    estimatedWeeklyVolume: '50 – 150 kg',
    speciesOfInterest: 'Yellowfin Tuna, Jumbo Tiger Prawns, Mud Crabs',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      // Auto close after showing thank you
    }, 4000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-xl rounded-2xl bg-[#091726] border border-slate-800 shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-[#06111D]">
          <div className="flex items-center gap-2.5">
            <Building className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="font-serif text-lg font-semibold text-white">
                Commercial & Restaurant Wholesale Supply
              </h2>
              <p className="text-[11px] text-slate-400">
                Direct Daily Landing Allocation for Resorts & Culinary Venues
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close wholesale modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-10 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
              <h3 className="font-serif text-xl font-semibold text-white">
                Inquiry Received by G.V.D. Lakmal
              </h3>
              <p className="text-xs text-slate-300 max-w-sm mx-auto">
                Our pier logistics manager will review your required species quota and contact you within 2 hours with our wholesale contract rates.
              </p>
              <button
                onClick={onClose}
                className="mt-4 px-5 py-2 text-xs bg-amber-500 text-slate-950 font-semibold rounded-lg hover:bg-amber-400 cursor-pointer"
              >
                Return to Storefront
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Establishment / Company Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Galle Heritage Dining"
                    value={formData.businessName}
                    onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Executive Chef / Buyer Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Chef Kasun Fernando"
                    value={formData.contactPerson}
                    onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Telephone / WhatsApp</label>
                  <input
                    type="tel"
                    required
                    placeholder="+94 77 ••• ••••"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Business Email</label>
                  <input
                    type="email"
                    required
                    placeholder="procurement@hotel.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Venue Classification</label>
                  <select
                    value={formData.businessType}
                    onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    <option>Fine Dining & Sushi Bar</option>
                    <option>Luxury Resort & Hotel</option>
                    <option>Private Yacht Charter</option>
                    <option>Gourmet Caterer / Villa Chef</option>
                    <option>Seafood Specialty Restaurant</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Estimated Weekly Intake</label>
                  <select
                    value={formData.estimatedWeeklyVolume}
                    onChange={(e) => setFormData({ ...formData, estimatedWeeklyVolume: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    <option>25 – 50 kg weekly</option>
                    <option>50 – 150 kg weekly</option>
                    <option>150 – 500 kg weekly</option>
                    <option>500+ kg bulk exporter tier</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Custom Portioned Cuts & Delivery Frequency</label>
                <textarea
                  rows={3}
                  placeholder="e.g. Daily delivery at 06:30 AM before prep. 20kg yellowfin loins skinless, 15kg jumbo tiger prawns shell-on."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-2 flex items-center justify-between flex-wrap gap-2">
                <a
                  href="https://wa.me/94778788454"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-mono transition-colors"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp Wholesale: 077 878 8454</span>
                </a>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Wholesale Proposal</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
