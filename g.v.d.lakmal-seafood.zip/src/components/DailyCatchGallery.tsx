import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, Plus, Minus, Check, Info, Sparkles, Scale, AlertCircle } from 'lucide-react';
import { SeafoodProduct, SeafoodCategory, PrepOption, CartItem } from '../types/seafood';
import { formatPrice } from '../utils/format';

interface DailyCatchGalleryProps {
  products: SeafoodProduct[];
  onAddToCart: (item: Omit<CartItem, 'id' | 'totalPrice'>) => void;
  onOpenProductDetail: (product: SeafoodProduct) => void;
}

export const DailyCatchGallery: React.FC<DailyCatchGalleryProps> = ({
  products,
  onAddToCart,
  onOpenProductDetail
}) => {
  const [selectedCategory, setSelectedCategory] = useState<SeafoodCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'stock'>('featured');
  
  // Local state for weight and prep selection per product card
  const [selectedWeights, setSelectedWeights] = useState<Record<string, number>>({});
  const [selectedPreps, setSelectedPreps] = useState<Record<string, PrepOption>>({});
  const [addedAnimation, setAddedAnimation] = useState<Record<string, boolean>>({});

  const categories: { id: SeafoodCategory; label: string }[] = [
    { id: 'all', label: 'All Fresh Catch' },
    { id: 'tuna', label: 'Tuna, Thalapath & Tora' },
    { id: 'crabs', label: 'Red Crabs' },
    { id: 'reef-fish', label: 'Reef Fish & Cuttlefish' },
    { id: 'boxes', label: 'Chef Curated Boxes' }
  ];

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        if (selectedCategory !== 'all' && p.category !== selectedCategory) {
          return false;
        }
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          return (
            p.name.toLowerCase().includes(q) ||
            p.scientificName.toLowerCase().includes(q) ||
            p.flavorProfile.toLowerCase().includes(q) ||
            p.origin.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.pricePerKg - b.pricePerKg;
        if (sortBy === 'price-desc') return b.pricePerKg - a.pricePerKg;
        if (sortBy === 'stock') return b.stockKg - a.stockKg;
        return 0; // featured default
      });
  }, [products, selectedCategory, searchQuery, sortBy]);

  const handleWeightChange = (productId: string, weight: number) => {
    setSelectedWeights((prev) => ({ ...prev, [productId]: weight }));
  };

  const handlePrepChange = (productId: string, prep: PrepOption) => {
    setSelectedPreps((prev) => ({ ...prev, [productId]: prep }));
  };

  const handleAdd = (product: SeafoodProduct) => {
    const weight = selectedWeights[product.id] || product.minWeightKg;
    const prep = selectedPreps[product.id] || product.prepOptions[0];

    onAddToCart({
      productId: product.id,
      product,
      selectedPrep: prep,
      weightKg: weight,
      quantity: 1
    });

    setAddedAnimation((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedAnimation((prev) => ({ ...prev, [product.id]: false }));
    }, 1500);
  };

  return (
    <section id="catch-gallery" className="py-16 scroll-mt-24 border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-amber-400 mb-2">
              <span>Daily Harvest Gallery</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Updated Live Every Dawn</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-white [text-wrap:balance]">
              Today’s Dawn Landings
            </h2>
            <p className="text-slate-400 text-sm sm:text-base mt-2 max-w-xl">
              Inspected at Mirissa Pier, hand-graded by master fishmongers, and prepared exactly to your culinary cut preference.
            </p>
          </div>

          {/* Quick Stats or Reassurance */}
          <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-900/80 border border-slate-800 px-3.5 py-2 rounded-lg shrink-0">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Currently live chilled inventory in Mirissa Cold Storage</span>
          </div>
        </div>

        {/* Interactive Controls Bar: Filter Tabs, Search & Sort */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 mb-8">
          
          {/* Functional Button Tabs for Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 lg:pb-0 scrollbar-none">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 font-semibold shadow-md'
                      : 'bg-slate-900/90 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Search & Sort Group */}
          <div className="flex items-center gap-3">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search tora, thalapath, red crab, cuttlefish, gal malu..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-900/90 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>

            <div className="relative shrink-0">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="pl-3 pr-8 py-2 text-xs bg-slate-900/90 border border-slate-800 rounded-lg text-slate-300 focus:outline-none focus:border-amber-400 transition-colors cursor-pointer appearance-none"
              >
                <option value="featured">Featured Landings</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="stock">Stock Available</option>
              </select>
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Product Cards Grid: 3 columns desktop */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center rounded-2xl border border-dashed border-slate-800 bg-slate-900/40">
            <AlertCircle className="w-10 h-10 text-slate-500 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-slate-300">No catches match your search query</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your search terms or view our complete daily landing inventory.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 text-xs bg-amber-500 text-slate-950 font-semibold rounded-lg hover:bg-amber-400 cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredProducts.map((product) => {
              const currentWeight = selectedWeights[product.id] || product.minWeightKg;
              const currentPrep = selectedPreps[product.id] || product.prepOptions[0];
              const calculatedPrice = product.pricePerKg * currentWeight;
              const isAdded = !!addedAnimation[product.id];

              return (
                <div
                  key={product.id}
                  className="rounded-2xl border border-slate-800/90 bg-[#0B1A2C] overflow-hidden flex flex-col group hover:border-slate-700 transition-all duration-300 shadow-xl"
                >
                  {/* Product Card Image Container (65-75% visual lead) */}
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-900">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Subtle Overlay gradient */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0B1A2C] via-transparent to-transparent opacity-80" />

                    {/* Clean Subtle Top Kicker Tag */}
                    {product.badge && (
                      <div className="absolute top-3 left-3 bg-[#07131F]/90 backdrop-blur-md border border-slate-700/80 px-2.5 py-1 rounded text-[11px] font-semibold text-amber-300 tracking-wide">
                        {product.badge}
                      </div>
                    )}

                    {/* Stock note */}
                    <div className="absolute top-3 right-3 bg-slate-950/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-slate-300 border border-slate-800">
                      {product.stockKg} kg left
                    </div>

                    {/* Inspection Modal Opener Button */}
                    <button
                      onClick={() => onOpenProductDetail(product)}
                      className="absolute bottom-3 right-3 p-2 rounded-lg bg-slate-950/80 hover:bg-slate-900 text-slate-300 hover:text-amber-300 border border-slate-800 backdrop-blur-md transition-colors cursor-pointer"
                      title="Inspect Provenance & Notes"
                    >
                      <Info className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Product Details Section */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Clean Unboxed Metadata with · separator */}
                      <div className="flex items-center gap-2 text-xs text-slate-400 mb-1.5 flex-wrap">
                        <span className="font-mono text-amber-400/90">{product.landedTime}</span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="truncate max-w-[140px]">{product.origin}</span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="text-emerald-400 font-medium">{product.grade}</span>
                      </div>

                      {/* Title */}
                      <h3
                        onClick={() => onOpenProductDetail(product)}
                        className="font-serif text-xl font-semibold text-white group-hover:text-amber-300 transition-colors cursor-pointer"
                      >
                        {product.name}
                      </h3>
                      
                      <p className="text-xs text-slate-500 italic mt-0.5">
                        {product.scientificName}
                      </p>

                      <p className="text-xs text-slate-300 mt-2.5 line-clamp-2 leading-relaxed">
                        {product.description}
                      </p>
                    </div>

                    {/* Interactive Preparation & Weight Selectors */}
                    <div className="mt-5 pt-4 border-t border-slate-800/80 space-y-3">
                      
                      {/* Prep Option Selection */}
                      <div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1 font-medium">
                          <span>Custom Cut / Preparation:</span>
                          <span className="text-amber-400">Included free</span>
                        </div>
                        <select
                          value={currentPrep}
                          onChange={(e) => handlePrepChange(product.id, e.target.value as PrepOption)}
                          aria-label={`Select preparation for ${product.name}`}
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-900/90 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400 transition-colors cursor-pointer"
                        >
                          {product.prepOptions.map((prep) => (
                            <option key={prep} value={prep}>
                              {prep}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Weight Selector - Unlimited */}
                      <div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5 font-medium">
                          <span className="flex items-center gap-1.5">
                            <span>Select Quantity / Weight:</span>
                            <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold tracking-wider">
                              Unlimited
                            </span>
                          </span>
                          <span className="font-mono text-slate-300">{formatPrice(product.pricePerKg)} / kg</span>
                        </div>

                        {/* Quick Presets */}
                        <div className="grid grid-cols-5 gap-1 mb-2">
                          {[0.5, 1, 2, 5, 10].map((w) => {
                            const isSelected = currentWeight === w;
                            return (
                              <button
                                key={w}
                                type="button"
                                onClick={() => handleWeightChange(product.id, w)}
                                className={`py-1 text-[11px] font-mono rounded border transition-colors cursor-pointer ${
                                  isSelected
                                    ? 'bg-amber-500 text-slate-950 border-amber-500 font-bold shadow-sm'
                                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                                }`}
                              >
                                {w}kg
                              </button>
                            );
                          })}
                        </div>

                        {/* Interactive Unlimited Stepper + Custom Direct Input */}
                        <div className="flex items-center justify-between bg-slate-950/90 rounded-lg border border-slate-800 p-1">
                          <button
                            type="button"
                            onClick={() => {
                              const newW = Math.max(0.5, Math.round((currentWeight - (currentWeight > 5 ? 1 : 0.5)) * 10) / 10);
                              handleWeightChange(product.id, newW);
                            }}
                            className="w-7 h-7 flex items-center justify-center rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                            title="Decrease weight"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>

                          <div className="flex items-center justify-center gap-1 flex-1 px-2">
                            <input
                              type="number"
                              min="0.1"
                              step="0.5"
                              value={currentWeight}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value);
                                if (!isNaN(val) && val > 0) {
                                  handleWeightChange(product.id, val);
                                }
                              }}
                              className="w-20 text-center font-mono text-sm font-bold text-amber-300 bg-transparent border-b border-transparent hover:border-slate-700 focus:border-amber-400 focus:outline-none"
                            />
                            <span className="text-xs font-mono text-slate-400">kg</span>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              const newW = Math.round((currentWeight + (currentWeight >= 5 ? 1 : 0.5)) * 10) / 10;
                              handleWeightChange(product.id, newW);
                            }}
                            className="w-7 h-7 flex items-center justify-center rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                            title="Increase weight (unlimited)"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Price & Primary Add Action */}
                      <div className="flex items-center justify-between gap-3 pt-2">
                        <div>
                          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block">
                            Subtotal ({currentWeight} kg)
                          </span>
                          <span className="font-mono text-xl font-bold text-white tabular-nums">
                            {formatPrice(calculatedPrice)}
                          </span>
                        </div>

                        <button
                          onClick={() => handleAdd(product)}
                          className={`px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                            isAdded
                              ? 'bg-emerald-500 text-slate-950 font-bold'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95 shadow-lg shadow-amber-500/10'
                          }`}
                        >
                          {isAdded ? (
                            <>
                              <Check className="w-4 h-4 stroke-[2.5]" />
                              <span>Added to Bag</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-4 h-4 stroke-[2.2]" />
                              <span>Add to Fresh Bag</span>
                            </>
                          )}
                        </button>
                      </div>

                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
