import React from 'react';
import { ShoppingBag, Anchor, Clock, Search, ShieldCheck, Lock, Cloud } from 'lucide-react';
import { CartItem } from '../types/seafood';
import { formatPrice } from '../utils/format';

interface HeaderProps {
  cart: CartItem[];
  onOpenCart: () => void;
  onOpenTracker: () => void;
  onOpenWholesale: () => void;
  onOpenOwnerInbox: () => void;
  onOpenSecurity?: () => void;
  onOpenGoogleDrive?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cart,
  onOpenCart,
  onOpenTracker,
  onOpenWholesale,
  onOpenOwnerInbox,
  onOpenSecurity,
  onOpenGoogleDrive
}) => {
  const totalItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => acc + item.totalPrice * item.quantity, 0);

  return (
    <>
      {/* Top Quiet Banner - Single Line */}
      <div className="bg-[#050D15] border-b border-slate-800/80 px-3 sm:px-4 py-2 text-xs text-slate-300 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto flex items-center justify-between min-w-max gap-4 sm:gap-6">
          <div className="flex items-center gap-3 shrink-0">
            <span className="flex items-center gap-1.5 text-amber-400 font-medium">
              <Clock className="w-3.5 h-3.5" />
              Dawn Landings Available
            </span>
            <span className="text-slate-600 hidden md:inline" aria-hidden="true">·</span>
            <span className="hidden md:inline text-slate-400">
              Mirissa Pier Landings at 04:30 AM · Unbroken 0°C–2°C Sea-Ice Cold Chain
            </span>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 text-xs font-medium text-slate-400 shrink-0">
            <a
              href="https://wa.me/94778788454"
              target="_blank"
              rel="noopener noreferrer"
              className="text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1 font-mono"
            >
              <span>WhatsApp: 077 878 8454</span>
            </a>
            <span className="text-slate-700" aria-hidden="true">·</span>
            <button
              onClick={onOpenTracker}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Track Live Order
            </button>
            <span className="text-slate-700" aria-hidden="true">·</span>
            <button
              onClick={onOpenOwnerInbox}
              className="text-amber-400 hover:text-amber-300 transition-colors cursor-pointer font-medium flex items-center gap-1.5 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20"
              title="Private Owner Portal - Requires PIN"
            >
              <Lock className="w-3 h-3 text-amber-400" />
              <span>Owner Portal</span>
            </button>
            {onOpenGoogleDrive && (
              <>
                <span className="text-slate-700 hidden sm:inline" aria-hidden="true">·</span>
                <button
                  onClick={onOpenGoogleDrive}
                  className="text-sky-400 hover:text-sky-300 transition-colors cursor-pointer font-medium flex items-center gap-1.5 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20"
                  title="Google Drive Cloud Receipts & Orders Archive"
                >
                  <Cloud className="w-3.5 h-3.5 text-sky-400" />
                  <span>Google Drive</span>
                </button>
              </>
            )}
            <span className="text-slate-700 hidden sm:inline" aria-hidden="true">·</span>
            <button
              onClick={onOpenWholesale}
              className="hover:text-amber-400 transition-colors cursor-pointer hidden md:inline"
            >
              Wholesale
            </button>
            {onOpenSecurity && (
              <>
                <span className="text-slate-700 hidden sm:inline" aria-hidden="true">·</span>
                <button
                  onClick={onOpenSecurity}
                  className="text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer flex items-center gap-1 font-mono text-[11px] bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/60"
                  title="256-Bit SSL Encryption & Anti-Bot Defense"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="hidden sm:inline">256-bit Secure</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-40 bg-[#07131F]/95 backdrop-blur-md border-b border-slate-800/90 transition-all">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-3 sm:gap-8">
          
          {/* Zone 1: Official Brand Logo & Wordmark */}
          <a
            href="/"
            className="flex items-center gap-2.5 sm:gap-3.5 group whitespace-nowrap shrink-0 focus:outline-none"
          >
            <div className="relative w-10 h-10 sm:w-13 sm:h-13 rounded-xl overflow-hidden bg-white p-1 shadow-lg shadow-sky-950/40 border border-slate-700/80 group-hover:border-amber-400/80 transition-all group-hover:scale-105 shrink-0">
              <img
                src="/assets/aistudio/Modern_Navy_Seafood_Logo_fceeff00.png"
                alt="G.V.D.Lakmal Seafood Official Brand Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-base sm:text-2xl font-bold tracking-tight text-white group-hover:text-amber-300 transition-colors">
                G.V.D.Lakmal Seafood
              </span>
              <span className="text-[9px] sm:text-[10px] tracking-wider uppercase text-amber-400 font-mono font-medium">
                Purveyor of Ocean Harvest · Est. 2008
              </span>
            </div>
          </a>

          {/* Zone 2: 4-5 clean single-line nav links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-300">
            <a
              href="#catch-gallery"
              className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
            >
              Daily Catch Gallery
            </a>
            <a
              href="#cold-chain"
              className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
            >
              Cold-Chain Process
            </a>
            <a
              href="#fleet-story"
              className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
            >
              Our Fleet & Ethics
            </a>
            <a
              href="#reviews"
              className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
            >
              Chef Endorsements
            </a>
            <button
              onClick={onOpenTracker}
              className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8 cursor-pointer"
            >
              Order Tracker
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenCart}
              className="flex items-center gap-3 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-semibold text-sm transition-all shadow-lg shadow-amber-500/10 cursor-pointer whitespace-nowrap shrink-0"
              aria-label={`View shopping cart with ${totalItemCount} items`}
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4 stroke-[2.2]" />
                {totalItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-slate-950 text-amber-300 text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-amber-400">
                    {totalItemCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline">Fresh Bag</span>
              <span className="font-mono tabular-nums text-xs bg-slate-950/20 px-1.5 py-0.5 rounded text-slate-900">
                {formatPrice(cartSubtotal)}
              </span>
            </button>
          </div>
        </div>
      </header>
    </>
  );
};
