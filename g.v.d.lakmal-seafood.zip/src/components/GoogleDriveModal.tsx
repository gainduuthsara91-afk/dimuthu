import React, { useState, useEffect } from 'react';
import {
  Cloud,
  FileText,
  UploadCloud,
  ExternalLink,
  Trash2,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  FolderOpen,
  LogOut,
  X,
  FileSpreadsheet,
  HardDrive
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  initDriveAuth,
  googleSignInWithDrive,
  googleSignOutDrive,
  listSeafoodDriveFiles,
  saveOrderReceiptToGoogleDrive,
  exportOrdersCsvToGoogleDrive,
  uploadFileToDrive,
  deleteFileFromDrive,
  getOrCreateSeafoodFolder,
  DriveFileInfo
} from '../services/googleDriveService';
import { Order } from '../types/seafood';

interface GoogleDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
}

export const GoogleDriveModal: React.FC<GoogleDriveModalProps> = ({
  isOpen,
  onClose,
  orders
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [files, setFiles] = useState<DriveFileInfo[]>([]);
  const [folderId, setFolderId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Destructive operation confirmation state (Mandatory for Google Workspace)
  const [fileToDelete, setFileToDelete] = useState<DriveFileInfo | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Listen to auth state
  useEffect(() => {
    const unsubscribe = initDriveAuth((authUser, authToken) => {
      setUser(authUser);
      setToken(authToken);
      if (authToken) {
        loadDriveData();
      } else {
        setFiles([]);
        setFolderId(null);
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const loadDriveData = async () => {
    setIsLoading(true);
    try {
      const fId = await getOrCreateSeafoodFolder();
      setFolderId(fId);
      const driveFiles = await listSeafoodDriveFiles(fId);
      setFiles(driveFiles);
    } catch (err: any) {
      console.error('Error loading Google Drive files:', err);
      setActionMessage({ type: 'error', text: err?.message || 'Failed to load files from Google Drive.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignIn = async () => {
    setIsLoading(true);
    setActionMessage(null);
    try {
      const result = await googleSignInWithDrive();
      setUser(result.user);
      setToken(result.accessToken);
      setActionMessage({ type: 'success', text: `Connected as ${result.user.email}. Google Drive access authorized.` });
      await loadDriveData();
    } catch (err: any) {
      console.error('Sign-in failed:', err);
      setActionMessage({ type: 'error', text: err?.message || 'Failed to sign in with Google.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await googleSignOutDrive();
      setUser(null);
      setToken(null);
      setFiles([]);
      setFolderId(null);
      setActionMessage({ type: 'info', text: 'Disconnected from Google Drive.' });
    } catch (err: any) {
      console.error('Sign-out error:', err);
    }
  };

  const handleExportCsv = async () => {
    if (orders.length === 0) {
      setActionMessage({ type: 'error', text: 'No orders available to export.' });
      return;
    }
    setIsLoading(true);
    try {
      const uploaded = await exportOrdersCsvToGoogleDrive(orders);
      setActionMessage({
        type: 'success',
        text: `Exported orders spreadsheet "${uploaded.name}" to Google Drive successfully!`
      });
      await loadDriveData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err?.message || 'Failed to export CSV to Google Drive.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveReceipt = async (order: Order) => {
    setIsLoading(true);
    try {
      const file = await saveOrderReceiptToGoogleDrive(order);
      setActionMessage({
        type: 'success',
        text: `Order #${order.id} receipt archived as "${file.name}" in Google Drive.`
      });
      await loadDriveData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err?.message || 'Failed to save receipt to Google Drive.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const uploaded = await uploadFileToDrive({
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        content: file,
        folderId: folderId || undefined
      });
      setActionMessage({
        type: 'success',
        text: `File "${uploaded.name}" uploaded to Google Drive successfully!`
      });
      await loadDriveData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err?.message || 'Failed to upload file to Google Drive.' });
    } finally {
      setIsLoading(false);
      e.target.value = '';
    }
  };

  const executeDeleteFile = async () => {
    if (!fileToDelete) return;
    setIsDeleting(true);
    try {
      await deleteFileFromDrive(fileToDelete.id);
      setActionMessage({
        type: 'success',
        text: `Permanently removed "${fileToDelete.name}" from Google Drive.`
      });
      setFileToDelete(null);
      await loadDriveData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err?.message || 'Failed to delete file from Google Drive.' });
    } finally {
      setIsDeleting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#07131F] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-[#050D15]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                Google Drive Cloud Records
                <span className="text-[10px] font-sans font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Workspace Connected
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                G.V.D.Lakmal Seafood official cloud archive and order receipt storage
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status / Feedback Banner */}
        {actionMessage && (
          <div
            className={`px-4 py-2.5 text-xs flex items-center justify-between border-b ${
              actionMessage.type === 'success'
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/40'
                : actionMessage.type === 'error'
                ? 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                : 'bg-sky-950/40 text-sky-300 border-sky-800/40'
            }`}
          >
            <div className="flex items-center gap-2">
              {actionMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              ) : actionMessage.type === 'error' ? (
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              ) : (
                <HardDrive className="w-4 h-4 shrink-0 text-sky-400" />
              )}
              <span>{actionMessage.text}</span>
            </div>
            <button
              onClick={() => setActionMessage(null)}
              className="text-slate-400 hover:text-white ml-2 text-xs"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 text-slate-200">
          
          {/* If NOT Signed in */}
          {!user || !token ? (
            <div className="py-6 text-center space-y-5">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Cloud className="w-8 h-8" />
              </div>
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-base font-bold text-white">Connect Google Drive</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Connect your Google Drive with permission to safely archive fresh seafood order receipts, export orders into spreadsheets, and store harbor landing documentation.
                </p>
              </div>

              {/* Official Google Sign-In Button format as mandated by Workspace skill */}
              <div className="pt-2 flex justify-center">
                <button
                  onClick={handleSignIn}
                  disabled={isLoading}
                  className="flex items-center gap-3 px-5 py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-medium text-sm transition-all shadow-md active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  <svg className="w-5 h-5" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                    <path fill="none" d="M0 0h48v48H0z" />
                  </svg>
                  <span>{isLoading ? 'Connecting Drive...' : 'Sign in with Google to Connect Drive'}</span>
                </button>
              </div>

              <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400">
                🔒 In-memory security: Access tokens are held securely only in active browser memory and never stored in persistent storage.
              </div>
            </div>
          ) : (
            /* If SIGNED IN */
            <div className="space-y-6">
              
              {/* Account & Folder Banner */}
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || 'User'}
                      className="w-10 h-10 rounded-full border border-amber-400/40"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center">
                      {(user.email || 'U')[0].toUpperCase()}
                    </div>
                  )}
                  <div>
                    <div className="text-xs font-semibold text-white flex items-center gap-2">
                      <span>{user.displayName || 'Authorized Owner'}</span>
                      <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/20">
                        Drive Active
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {user.email}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={loadDriveData}
                    disabled={isLoading}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors text-xs flex items-center gap-1 cursor-pointer"
                    title="Refresh Drive files"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                    <span className="text-xs">Refresh</span>
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="px-2.5 py-1 text-slate-400 hover:text-rose-300 rounded-lg hover:bg-rose-950/30 transition-colors text-xs flex items-center gap-1 border border-slate-800 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Disconnect</span>
                  </button>
                </div>
              </div>

              {/* Dedicated Google Drive Folder Badge */}
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-amber-300">
                  <FolderOpen className="w-4 h-4 shrink-0 text-amber-400" />
                  <span className="font-medium">Google Drive Folder:</span>
                  <span className="font-semibold text-white">G.V.D.Lakmal Seafood Records</span>
                </div>
                {folderId && (
                  <a
                    href={`https://drive.google.com/drive/folders/${folderId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:text-amber-300 flex items-center gap-1 font-mono text-[11px]"
                  >
                    <span>Open in Drive</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

              {/* Quick Actions Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Action 1: Export CSV */}
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between space-y-3">
                  <div>
                    <div className="flex items-center gap-2 text-white font-semibold text-xs mb-1">
                      <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                      <span>Sync All Orders (Spreadsheet)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Export all {orders.length} current customer orders into a clean CSV spreadsheet saved in your Drive.
                    </p>
                  </div>
                  <button
                    onClick={handleExportCsv}
                    disabled={isLoading}
                    className="w-full py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <UploadCloud className="w-3.5 h-3.5" />
                    <span>Export Orders to Google Drive</span>
                  </button>
                </div>

                {/* Action 2: Upload Custom Catch/Compliance Document */}
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between space-y-3">
                  <div>
                    <div className="flex items-center gap-2 text-white font-semibold text-xs mb-1">
                      <UploadCloud className="w-4 h-4 text-sky-400" />
                      <span>Upload Harbor & Catch Document</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Upload catch logs, pier inspection certificates, or cold-chain reports directly to the seafood Drive folder.
                    </p>
                  </div>
                  <label className="w-full py-2 px-3 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer">
                    <UploadCloud className="w-3.5 h-3.5" />
                    <span>Upload Document to Drive</span>
                    <input
                      type="file"
                      onChange={handleFileUpload}
                      className="hidden"
                      disabled={isLoading}
                    />
                  </label>
                </div>
              </div>

              {/* Recent Orders Quick Archive Section */}
              {orders.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                    <span>Quick Archive Recent Receipts to Drive</span>
                    <span className="text-[11px] text-slate-500">{orders.length} orders on file</span>
                  </div>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {orders.slice(0, 5).map((ord) => (
                      <div
                        key={ord.id}
                        className="p-2.5 rounded-lg bg-slate-900/50 border border-slate-800/80 flex items-center justify-between text-xs"
                      >
                        <div className="min-w-0 pr-2">
                          <div className="font-semibold text-white truncate">
                            #{ord.id} — {ord.customerName}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            Rs. {Math.round(ord.totalAmount).toLocaleString('en-LK')} · {ord.createdAt}
                          </div>
                        </div>
                        <button
                          onClick={() => handleSaveReceipt(ord)}
                          disabled={isLoading}
                          className="shrink-0 px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[11px] font-medium flex items-center gap-1 transition-all cursor-pointer"
                        >
                          <UploadCloud className="w-3 h-3" />
                          <span>Save to Drive</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Live Files on Google Drive */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-amber-400" />
                    <span>Stored Drive Files ({files.length})</span>
                  </div>
                  {folderId && (
                    <a
                      href={`https://drive.google.com/drive/folders/${folderId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-amber-400 hover:text-amber-300 text-[11px] flex items-center gap-1"
                    >
                      <span>View in Google Drive</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>

                {files.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-500 bg-slate-900/30 rounded-xl border border-slate-800/50">
                    No files found in the dedicated folder yet. Click "Export Orders" or "Save to Drive" above to create your first archive!
                  </div>
                ) : (
                  <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                    {files.map((file) => (
                      <div
                        key={file.id}
                        className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800 flex items-center justify-between text-xs hover:border-slate-700 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 min-w-0 pr-2">
                          <FileText className="w-4 h-4 text-amber-400 shrink-0" />
                          <div className="min-w-0">
                            <div className="text-white font-medium truncate" title={file.name}>
                              {file.name}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {file.createdTime ? new Date(file.createdTime).toLocaleDateString() : 'Recent'}
                              {file.size ? ` · ${(Number(file.size) / 1024).toFixed(1)} KB` : ''}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {file.webViewLink && (
                            <a
                              href={file.webViewLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] flex items-center gap-1 transition-colors"
                            >
                              <span>View</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          )}
                          
                          {/* Delete button triggers explicit confirmation modal */}
                          <button
                            onClick={() => setFileToDelete(file)}
                            className="p-1 text-slate-400 hover:text-rose-400 rounded hover:bg-rose-950/30 transition-colors cursor-pointer"
                            title="Delete file from Google Drive"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-800 bg-[#050D15] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span>Powered by Google Workspace API</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>

      {/* MANDATORY USER CONFIRMATION DIALOG FOR DESTRUCTIVE ACTIONS */}
      {fileToDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-[#0b1726] border border-rose-800/80 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-full bg-rose-950/60 border border-rose-800 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Confirm Permanent Deletion</h4>
                <p className="text-xs text-slate-400">Google Drive Destructive Action Confirmation</p>
              </div>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 text-xs space-y-1">
              <div className="text-slate-400">File to be deleted from Google Drive:</div>
              <div className="font-semibold text-white font-mono break-all">{fileToDelete.name}</div>
            </div>

            <p className="text-xs text-rose-300">
              Are you sure you want to permanently delete this file from Google Drive? This action cannot be undone.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setFileToDelete(null)}
                disabled={isDeleting}
                className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={executeDeleteFile}
                disabled={isDeleting}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-lg shadow-rose-900/30 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3 h-3" />
                    <span>Confirm Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
