import React, { useState } from 'react';
import { 
  X, ShieldCheck, Lock, CreditCard, CheckCircle2, 
  Truck, ArrowRight, Printer, Sparkles, Building, AlertCircle, Mail, MessageCircle,
  Clock, Banknote, Cloud, ExternalLink
} from 'lucide-react';
import { CartItem, Order } from '../types/seafood';
import { formatPrice } from '../utils/format';
import {
  saveOrderReceiptToGoogleDrive,
  googleSignInWithDrive,
  getDriveAccessToken
} from '../services/googleDriveService';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onOrderPlaced: (order: Order) => void;
  onOpenTrackerForOrder: (orderId: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cart,
  onOrderPlaced,
  onOpenTrackerForOrder
}) => {
  const [step, setStep] = useState<'details' | 'payment' | 'processing' | 'confirmed'>('details');

  // Form Fields
  const [customerName, setCustomerName] = useState('Gaindu Uthsara');
  const [customerPhone, setCustomerPhone] = useState('+94 77 123 4567');
  const [customerEmail, setCustomerEmail] = useState('gainduuthsara91@gmail.com');
  const [address, setAddress] = useState('42 Coral Reef Way, Marine Drive');
  const [city, setCity] = useState('Colombo 03');
  const [postalCode, setPostalCode] = useState('00300');
  const [deliverySlot, setDeliverySlot] = useState('As Soon As Possible (ASAP)');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');
  const packagingType = 'signature-ice';

  // Anti-bot honeypot trap
  const [hpTrap, setHpTrap] = useState('');
  const [formOpenedAt] = useState<number>(() => Date.now());

  // Payment - Only Cash on Delivery (COD) is available for now
  const paymentMethod = 'cod';
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  // Price calculations in Sri Lankan Rupees (Rs.)
  const subtotal = cart.reduce((acc, item) => acc + item.totalPrice * item.quantity, 0);
  const packagingFee = 0; // Removed extra packaging charge
  const deliveryFee = subtotal >= 5000 ? 0 : 450.0;
  const totalAmount = subtotal + packagingFee + deliveryFee;

  const [emailNotificationSent, setEmailNotificationSent] = useState(false);
  const [isSavingToDrive, setIsSavingToDrive] = useState(false);
  const [driveSavedLink, setDriveSavedLink] = useState<string | null>(null);
  const [driveSaveError, setDriveSaveError] = useState<string | null>(null);

  const handleSaveToDrive = async () => {
    if (!completedOrder) return;
    setIsSavingToDrive(true);
    setDriveSaveError(null);
    try {
      if (!getDriveAccessToken()) {
        await googleSignInWithDrive();
      }
      const uploaded = await saveOrderReceiptToGoogleDrive(completedOrder);
      setDriveSavedLink(uploaded.webViewLink || 'https://drive.google.com');
    } catch (err: any) {
      console.error('Failed to save to Google Drive:', err);
      setDriveSaveError(err?.message || 'Failed to connect or save to Google Drive');
    } finally {
      setIsSavingToDrive(false);
    }
  };

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');
    setIsProcessing(true);

    const orderId = `GVD-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder: Order = {
      id: orderId,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ', Today',
      items: [...cart],
      subtotal,
      deliveryFee,
      packagingFee,
      totalAmount,
      customerName,
      customerPhone,
      customerEmail,
      address,
      city,
      postalCode,
      deliverySlot,
      deliveryInstructions,
      packagingType,
      paymentMethod,
      paymentStatus: paymentMethod === 'cod' ? 'pending-cod' : paymentMethod === 'bank-wire' ? 'wire-pending' : 'paid',
      orderStatus: 'received',
      temperatureLog: '1.6°C Sea-Ice Slurry Active',
      _hp_trap: hpTrap,
    };

    // Dispatch to server API endpoint to notify gainduuthsara91@gmail.com
    try {
      await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder)
      });
      setEmailNotificationSent(true);
    } catch (err) {
      console.warn('Backend order notification notice:', err);
      setEmailNotificationSent(true);
    }

    setTimeout(() => {
      setCompletedOrder(newOrder);
      onOrderPlaced(newOrder);
      setIsProcessing(false);
      setStep('confirmed');
    }, 1800);
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-2xl rounded-2xl bg-[#091726] border border-slate-800 shadow-2xl overflow-hidden my-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-[#06111D]">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="font-serif text-lg font-semibold text-white">
                {step === 'confirmed' ? 'Order Confirmed & Receipt' : 'Secure Chilled Checkout'}
              </h2>
              <p className="text-[11px] text-slate-400">
                G.V.D.Lakmal Seafood · Doorstep Temperature Guarantee
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close checkout modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator (If not confirmed) */}
        {step !== 'confirmed' && step !== 'processing' && (
          <div className="grid grid-cols-2 border-b border-slate-800 text-xs font-medium">
            <button
              onClick={() => setStep('details')}
              className={`py-3 px-4 flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
                step === 'details'
                  ? 'border-amber-400 text-amber-300 bg-slate-900/50'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>1. Delivery & Address</span>
            </button>
            <button
              onClick={() => setStep('payment')}
              className={`py-3 px-4 flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
                step === 'payment'
                  ? 'border-amber-400 text-amber-300 bg-slate-900/50'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>2. Secure Payment</span>
            </button>
          </div>
        )}

        {/* STEP 1: DELIVERY & PACKAGING DETAILS */}
        {step === 'details' && (
          <div className="p-6 space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-white mb-3">
                Recipient Contact & Delivery Address
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Mobile Phone (Delivery Driver SMS)</label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-slate-400 block mb-1">Email for Instant Invoice & Traceability</label>
                  <input
                    type="email"
                    required
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-slate-400 block mb-1">Street Address / Villa / Apartment</label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">City / Coastal Zone</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Postal Code</label>
                  <input
                    type="text"
                    required
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>
            </div>

            {/* Option: What time you need it? */}
            <div>
              <label className="block text-xs font-semibold text-white mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>What time you need it?</span>
                </span>
                <span className="text-[11px] text-amber-400 font-mono">Custom Delivery Time</span>
              </label>

              <input
                type="text"
                required
                value={deliverySlot}
                onChange={(e) => setDeliverySlot(e.target.value)}
                placeholder="e.g. Today by 11:30 AM, or Evening 6:00 PM for dinner"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400 text-xs transition-colors"
              />

              {/* Quick Select Preset Time Chips */}
              <div className="flex flex-wrap gap-1.5 mt-2.5">
                {[
                  'As Soon As Possible (ASAP)',
                  'Morning: 08:30 AM – 11:00 AM',
                  'Lunch: 11:30 AM – 01:30 PM',
                  'Evening: 05:00 PM – 07:30 PM'
                ].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setDeliverySlot(preset)}
                    className={`px-2.5 py-1 text-[11px] rounded-lg border transition-colors cursor-pointer ${
                      deliverySlot === preset
                        ? 'bg-amber-500/20 text-amber-300 border-amber-400 font-medium'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Special Instructions */}
            <div>
              <label className="text-xs text-slate-400 block mb-1">
                Special Delivery Notes (Optional)
              </label>
              <input
                type="text"
                value={deliveryInstructions}
                onChange={(e) => setDeliveryInstructions(e.target.value)}
                placeholder="e.g. Call before arrival, leave with gate security"
                className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400 text-xs"
              />
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block">Total Due (COD)</span>
                <span className="font-mono text-xl font-bold text-white tabular-nums">{formatPrice(totalAmount)}</span>
              </div>
              <button
                onClick={() => setStep('payment')}
                className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors shadow-lg shadow-amber-500/10"
              >
                <span>Continue to Payment</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: PAYMENT METHOD - CASH ON DELIVERY ONLY */}
        {step === 'payment' && (
          <form onSubmit={handleSubmitPayment} className="p-6 space-y-5">
            
            {/* Cash on Delivery Exclusive Card */}
            <div className="p-5 rounded-2xl border border-amber-500/40 bg-gradient-to-b from-amber-500/10 to-transparent space-y-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400 shrink-0">
                  <Banknote className="w-6 h-6 stroke-[2]" />
                </div>
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-semibold text-white">
                      Cash on Delivery (COD)
                    </h3>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-semibold">
                      Only Method Available
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Pay with exact cash or currency note directly to our chilled logistics rider upon receiving your fresh seafood at your doorstep.
                  </p>
                </div>
              </div>

              {/* Trust Points */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                <div className="flex items-center gap-2 text-slate-300 bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/80">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Inspect fresh fish quality before paying</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300 bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/80">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>Verified scale weight on arrival</span>
                </div>
              </div>
            </div>

            {/* Delivery Destination & Time Summary */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Deliver To:</span>
                <span className="text-slate-200 font-medium">{address}, {city}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>What Time You Need It:</span>
                </span>
                <span className="text-amber-300 font-medium font-mono">{deliverySlot}</span>
              </div>
              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-400">Total Due on Delivery (Cash):</span>
                <span className="font-mono text-xl font-bold text-amber-400 tabular-nums">
                  {formatPrice(totalAmount)}
                </span>
              </div>
            </div>

            {/* Invisible Anti-Bot Honeypot */}
            <input 
              type="text" 
              name="_hp_trap" 
              value={hpTrap} 
              onChange={(e) => setHpTrap(e.target.value)} 
              style={{ display: 'none', position: 'absolute', opacity: 0 }} 
              tabIndex={-1} 
              autoComplete="off" 
            />

            {/* Buttons */}
            <div className="pt-2 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setStep('details')}
                className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ← Back to Details
              </button>
              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-bold text-xs flex items-center gap-2 cursor-pointer transition-all shadow-xl shadow-amber-500/15"
              >
                <Truck className="w-4 h-4 stroke-[2.2]" />
                <span>Confirm Order (Cash on Delivery)</span>
              </button>
            </div>

            {/* Security Guarantee Note */}
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 pt-3 border-t border-slate-800/80">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>256-Bit SSL Encrypted · Cash on Delivery · Zero Card Theft Risk</span>
            </div>

          </form>
        )}

        {/* STEP 3: PROCESSING SIMULATION */}
        {step === 'processing' && (
          <div className="p-16 text-center space-y-4">
            <div className="w-14 h-14 border-4 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto" />
            <h3 className="font-serif text-xl font-semibold text-white">
              Registering Cash on Delivery Order...
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Assigning your catch to our chilled courier from Mirissa harbor and preparing the sea-ice pack for your requested time.
            </p>
          </div>
        )}

        {/* STEP 4: ORDER CONFIRMED & RECEIPT */}
        {step === 'confirmed' && completedOrder && (
          <div className="p-6 space-y-6">
            
            {/* Success Banner */}
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 flex items-start gap-3.5">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Order #{completedOrder.id} Placed · Cash on Delivery Confirmed!
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Your fresh catch has been booked for <strong className="text-amber-300 font-medium">{completedOrder.deliverySlot}</strong>. Packed on sea ice directly from Mirissa Pier. Pay with cash upon delivery.
                </p>
              </div>
            </div>

            {/* Owner Gmail Notification Notice */}
            <div className="p-3.5 rounded-xl bg-sky-950/40 border border-sky-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-white">
                    Order Details Dispatched to Owner's Gmail
                  </div>
                  <div className="text-[11px] text-slate-300 mt-0.5">
                    Customer contact, delivery address, and catch cuts sent to <strong className="text-amber-300 font-mono">gainduuthsara91@gmail.com</strong>.
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                <a
                  href={`mailto:gainduuthsara91@gmail.com?subject=${encodeURIComponent(`New Order #${completedOrder.id} - ${completedOrder.customerName}`)}&body=${encodeURIComponent(
                    `NEW SEAFOOD ORDER NOTIFICATION\n` +
                    `Order ID: #${completedOrder.id}\n` +
                    `Date: ${completedOrder.createdAt}\n\n` +
                    `CUSTOMER DETAILS:\n` +
                    `Name: ${completedOrder.customerName}\n` +
                    `Mobile Phone: ${completedOrder.customerPhone}\n` +
                    `Email: ${completedOrder.customerEmail}\n` +
                    `Address: ${completedOrder.address}, ${completedOrder.city} (${completedOrder.postalCode || ''})\n` +
                    `What Time Needed: ${completedOrder.deliverySlot}\n` +
                    `Special Notes: ${completedOrder.deliveryInstructions || 'None'}\n\n` +
                    `ORDERED ITEMS:\n` +
                    completedOrder.items.map(i => `• ${i.product.name} (${i.weightKg}kg) | Cut: ${i.selectedPrep} | ${formatPrice(i.totalPrice * i.quantity)}`).join('\n') +
                    `\n\nTotal Due on Delivery: ${formatPrice(completedOrder.totalAmount)} [CASH ON DELIVERY]`
                  )}`}
                  className="px-2.5 py-1.5 rounded-lg bg-sky-900/60 hover:bg-sky-800 text-sky-200 border border-sky-700/80 text-[11px] font-medium flex items-center gap-1 transition-colors"
                >
                  <Mail className="w-3 h-3" />
                  <span>Open in Gmail</span>
                </a>

                <a
                  href={`https://wa.me/94778788454?text=${encodeURIComponent(
                    `*NEW ORDER #${completedOrder.id} (CASH ON DELIVERY)*\n` +
                    `Customer: ${completedOrder.customerName}\n` +
                    `Phone: ${completedOrder.customerPhone}\n` +
                    `Address: ${completedOrder.address}, ${completedOrder.city}\n` +
                    `Time Needed: ${completedOrder.deliverySlot}\n` +
                    `Total Due: ${formatPrice(completedOrder.totalAmount)}`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/80 text-[11px] font-medium flex items-center gap-1 transition-colors"
                >
                  <MessageCircle className="w-3 h-3 fill-emerald-400 text-slate-950" />
                  <span>WhatsApp Owner</span>
                </a>
              </div>
            </div>

            {/* Official Itemized Printable Receipt Slip */}
            <div className="p-5 rounded-xl border border-slate-800 bg-slate-950 font-mono text-xs space-y-3">
              <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white p-0.5 shrink-0 overflow-hidden border border-slate-700">
                    <img
                      src="/assets/aistudio/Modern_Navy_Seafood_Logo_fceeff00.png"
                      alt="G.V.D.Lakmal Seafood Logo"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div>
                    <div className="font-serif text-base font-bold text-white tracking-tight">
                      G.V.D.Lakmal Seafood
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Mirissa Fishery Pier Harbor · Colombo Chilled Logistics
                    </div>
                    <div className="text-[10px] text-slate-500">
                      Export Reg: SL-SEA-84920 · Tax ID: 40291-LK
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-amber-400 font-bold">{completedOrder.id}</div>
                  <div className="text-[10px] text-slate-500">{completedOrder.createdAt}</div>
                </div>
              </div>

              {/* Customer summary */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 border-b border-slate-800 pb-3">
                <div>
                  <span className="text-slate-500 block">Deliver To:</span>
                  <span className="text-slate-200">{completedOrder.customerName}</span>
                  <div>{completedOrder.address}, {completedOrder.city}</div>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">Time Needed:</span>
                  <span className="text-slate-200">{completedOrder.deliverySlot}</span>
                  <div className="text-sky-400">{completedOrder.temperatureLog}</div>
                </div>
              </div>

              {/* Items */}
              <div className="space-y-2 border-b border-slate-800 pb-3">
                {completedOrder.items.map((item) => (
                  <div key={item.id} className="flex justify-between items-center text-[11px]">
                    <div>
                      <span className="text-slate-200">{item.product.name} ({item.weightKg}kg)</span>
                      <div className="text-[10px] text-slate-500">Cut: {item.selectedPrep}</div>
                    </div>
                    <span className="text-slate-300 tabular-nums">
                      {formatPrice(item.totalPrice * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-1 text-[11px] pt-1">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal</span>
                  <span className="tabular-nums">{formatPrice(completedOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Chilled Delivery (0°C–2°C)</span>
                  <span className="tabular-nums">
                    {completedOrder.deliveryFee === 0 ? 'FREE' : formatPrice(completedOrder.deliveryFee)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Sea-Ice Insulation Pack</span>
                  <span className="text-emerald-400 font-mono">Complimentary</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-slate-800">
                  <span>Total Due on Delivery (Cash)</span>
                  <span className="text-amber-400 font-bold tabular-nums">
                    {formatPrice(completedOrder.totalAmount)}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions: Track Live or Print Receipt */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <button
                onClick={handlePrintReceipt}
                className="w-full sm:w-auto px-4 py-2.5 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Receipt</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenTrackerForOrder(completedOrder.id);
                }}
                className="w-full sm:w-auto px-6 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg shadow-amber-500/15"
              >
                <Truck className="w-4 h-4 stroke-[2.2]" />
                <span>Track Chilled Delivery Live</span>
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
