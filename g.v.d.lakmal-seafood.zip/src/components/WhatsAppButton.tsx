import React, { useState } from 'react';
import { MessageCircle, X, Send, ArrowUpRight, Clock, ShieldCheck } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const phoneNumber = '94778788454';
  const displayPhone = '077 878 8454';

  const defaultQuestions = [
    "Hello! What is today's fresh yellowfin tuna price?",
    "Do you have live giant tiger prawns available right now?",
    "Can you deliver to my address today?",
    "I would like to request wholesale restaurant pricing."
  ];

  const handleOpenWhatsApp = (message?: string) => {
    const text = message 
      ? encodeURIComponent(message)
      : encodeURIComponent("Hello G.V.D.Lakmal Seafood, I would like to inquire about today's fresh catch.");
    window.open(`https://wa.me/${phoneNumber}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      
      {/* Expanded Quick-Chat Card */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 rounded-2xl bg-[#091726] border border-slate-700/90 shadow-2xl overflow-hidden transition-all duration-300">
          
          {/* Header */}
          <div className="bg-[#050E17] p-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950 font-bold shadow-md">
                <MessageCircle className="w-5 h-5 fill-slate-950" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-white">
                  G.V.D.Lakmal Seafood
                </h4>
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>Online · Mirissa Pier Dispatch</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              aria-label="Close WhatsApp chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800/80 text-slate-300 leading-relaxed">
              <p className="font-medium text-white mb-1">
                Ayubowan! How can we assist with your fresh catch today?
              </p>
              <p className="text-[11px] text-slate-400">
                Direct hotline & WhatsApp: <strong className="text-amber-400 font-mono">{displayPhone}</strong> (+94 77 878 8454).
              </p>
            </div>

            {/* Quick Prompts */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block">
                Quick Inquiries:
              </span>
              {defaultQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleOpenWhatsApp(q)}
                  className="w-full text-left p-2 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-800/80 text-slate-300 hover:text-amber-300 transition-colors flex items-center justify-between gap-2 cursor-pointer text-[11px]"
                >
                  <span className="truncate">{q}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                </button>
              ))}
            </div>

            {/* Direct Start Chat Button */}
            <button
              onClick={() => handleOpenWhatsApp()}
              className="w-full py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg shadow-emerald-500/15"
            >
              <MessageCircle className="w-4 h-4 fill-slate-950" />
              <span>Chat Directly: {displayPhone}</span>
            </button>
          </div>

        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        onClick={() => setIsOpen((prev) => !prev)}
        className="group flex items-center gap-2.5 pl-3.5 pr-4 py-2.5 rounded-full bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs shadow-xl shadow-emerald-500/20 transition-all cursor-pointer border border-emerald-400/50"
        aria-label="Contact G.V.D.Lakmal on WhatsApp 0778788454"
      >
        <MessageCircle className="w-5 h-5 fill-slate-950" />
        <span className="hidden sm:inline">WhatsApp: {displayPhone}</span>
        <span className="sm:hidden font-mono text-[11px]">{displayPhone}</span>
      </button>

    </div>
  );
};
