import React from 'react';
import { Anchor, ShieldCheck, Mail, Phone, MapPin } from 'lucide-react';
import { FLEET_INFO } from '../data/seafoodData';

interface FooterProps {
  onOpenTracker: () => void;
  onOpenWholesale: () => void;
  onOpenSecurity?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenTracker, onOpenWholesale, onOpenSecurity }) => {
  return (
    <footer className="border-t border-slate-800 bg-[#050D15] text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-white p-1 shadow-md border border-slate-700/80 overflow-hidden shrink-0">
                <img
                  src="/assets/aistudio/Modern_Navy_Seafood_Logo_fceeff00.png"
                  alt="G.V.D.Lakmal Seafood Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-xl font-semibold text-white tracking-tight">
                  G.V.D.Lakmal Seafood
                </span>
                <span className="text-[10px] uppercase tracking-wider text-amber-400 font-mono">
                  Direct Pier Landings · Est. 2008
                </span>
              </div>
            </div>
            
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Artisan ocean fishery and direct cold-chain purveyor founded by G.V.D. Lakmal. Supplying export-grade yellowfin tuna, colossal prawns, and daily fresh catch directly to kitchens within hours of dawn landing.
            </p>

            <div className="space-y-1.5 pt-2 text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Mirissa International Fishery Harbor, Southern Province, Sri Lanka</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>
                  Pier Direct & WhatsApp:{' '}
                  <a
                    href="https://wa.me/94778788454"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-emerald-400 hover:text-emerald-300 font-mono font-medium underline-offset-4 hover:underline"
                  >
                    077 878 8454
                  </a>{' '}
                  (+94 77 878 8454)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>catch@gvd-lakmalseafood.com</span>
              </div>
            </div>
          </div>

          {/* Nav Col 1 */}
          <div>
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-semibold mb-3">
              Daily Landings
            </h4>
            <ul className="space-y-2">
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  Yellowfin Tuna Loins
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  Indo-Pacific Sailfish [Thalapath]
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  King Fish [Tora]
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  Red Crab
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  Ocean Barramundi (Modha)
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  Fresh Sappara
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  White Mullet [Gal Malu]
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  Frozen Cuttle Fish Cone
                </a>
              </li>
              <li>
                <a href="#catch-gallery" className="hover:text-amber-300 transition-colors">
                  Chef’s Feast Boxes
                </a>
              </li>
            </ul>
          </div>

          {/* Nav Col 2 */}
          <div>
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-semibold mb-3">
              Cold Chain & Services
            </h4>
            <ul className="space-y-2">
              <li>
                <a href="#cold-chain" className="hover:text-amber-300 transition-colors">
                  0°C–2°C Sea-Ice Assurance
                </a>
              </li>
              <li>
                <button onClick={onOpenTracker} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  Live Order GPS Tracker
                </button>
              </li>
              <li>
                <button onClick={onOpenWholesale} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  Hotel & Restaurant Supply
                </button>
              </li>
              <li>
                <a href="#fleet-story" className="hover:text-amber-300 transition-colors">
                  Day-Boat Fleet Registry
                </a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-amber-300 transition-colors">
                  Chef & Yacht Endorsements
                </a>
              </li>
            </ul>
          </div>

          {/* Nav Col 3: Standards */}
          <div>
            <h4 className="font-mono text-xs uppercase tracking-wider text-white font-semibold mb-3">
              Certifications
            </h4>
            <ul className="space-y-2 text-[11px] text-slate-400">
              {FLEET_INFO.certifications.map((cert) => (
                <li key={cert} className="flex items-start gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{cert}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Bottom Bar: Quiet Copyright */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} G.V.D.Lakmal Seafood. All rights reserved. Handcrafted for oceanic culinary excellence.
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <span className="hover:text-slate-400 transition-colors">Pier Landing Operations: 04:00 AM – 18:00 PM Daily</span>
            <span aria-hidden="true">·</span>
            <a
              href="/gvd-lakmal-seafood-full-backup.zip"
              download="GVD-Lakmal-Seafood-Website-Backup.zip"
              className="text-amber-400 hover:text-amber-300 transition-colors flex items-center gap-1 font-medium"
              title="Download an offline backup copy of this website and photos to your computer"
            >
              <span>Download Website Backup (.ZIP)</span>
            </a>
            <span aria-hidden="true">·</span>
            {onOpenSecurity ? (
              <button
                onClick={onOpenSecurity}
                className="text-emerald-400 hover:text-emerald-300 font-mono cursor-pointer transition-colors flex items-center gap-1 hover:underline"
                title="View Enterprise Cybersecurity & Protection Center"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>256-bit Verified Security Center</span>
              </button>
            ) : (
              <span className="text-emerald-400 font-mono">256-bit Secure Checkout</span>
            )}
          </div>
        </div>

      </div>
    </footer>
  );
};
