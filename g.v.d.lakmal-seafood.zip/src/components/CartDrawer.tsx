import React from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ShieldCheck, ArrowRight, Truck } from 'lucide-react';
import { CartItem } from '../types/seafood';
import { formatPrice } from '../utils/format';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (itemId: string, newQuantity: number) => void;
  onRemoveItem: (itemId: string) => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout
}) => {
  if (!isOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.totalPrice * item.quantity, 0);
  const freeDeliveryThreshold = 5000.0;
  const progressToFree = Math.min(100, (subtotal / freeDeliveryThreshold) * 100);
  const amountToFree = Math.max(0, freeDeliveryThreshold - subtotal);
  const deliveryFee = subtotal >= freeDeliveryThreshold || subtotal === 0 ? 0 : 450.0;
  const total = subtotal + deliveryFee;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#081523] border-l border-slate-800 shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="p-5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-amber-400" />
              <h2 className="font-serif text-lg font-semibold text-white">
                Your Fresh Seafood Bag
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close cart drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Delivery Bar */}
          <div className="bg-[#050D15] p-3 border-b border-slate-800/80 text-xs">
            {amountToFree > 0 ? (
              <div>
                <p className="text-slate-300 mb-1.5">
                  Add <strong className="text-amber-400 font-mono">{formatPrice(amountToFree)}</strong> more for <span className="text-emerald-400 font-medium">Free Chilled Delivery</span>
                </p>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-400 h-full transition-all duration-300"
                    style={{ width: `${progressToFree}%` }}
                  />
                </div>
              </div>
            ) : (
              <p className="text-emerald-400 font-medium flex items-center gap-1.5">
                <Truck className="w-4 h-4" />
                <span>You unlocked Free Insulated Doorstep Delivery!</span>
              </p>
            )}
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="py-20 text-center">
                <ShoppingBag className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-sm font-medium text-slate-300">Your fresh bag is empty</p>
                <p className="text-xs text-slate-500 mt-1">
                  Explore today’s dawn catch and pick your custom cutting options.
                </p>
                <button
                  onClick={onClose}
                  className="mt-4 px-4 py-2 text-xs bg-amber-500 text-slate-950 font-semibold rounded-lg hover:bg-amber-400 transition-colors cursor-pointer"
                >
                  Browse Today’s Catch
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-xl border border-slate-800 bg-slate-900/80 flex gap-3.5 group"
                >
                  {/* Thumbnail */}
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-lg object-cover bg-slate-950 shrink-0"
                    referrerPolicy="no-referrer"
                  />

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-semibold text-white truncate">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="text-slate-500 hover:text-rose-400 transition-colors p-0.5 cursor-pointer"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-[11px] text-amber-400/90 truncate mt-0.5">
                      Prep: {item.selectedPrep}
                    </p>

                    <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                      Weight: {item.weightKg} kg ({formatPrice(item.product.pricePerKg)}/kg)
                    </p>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/80">
                      {/* Quantity Stepper */}
                      <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                          className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-mono font-medium text-white px-1">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                          className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Total Item Price */}
                      <span className="font-mono text-xs font-bold text-white tabular-nums">
                        {formatPrice(item.totalPrice * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Action */}
          {cart.length > 0 && (
            <div className="p-5 border-t border-slate-800 bg-[#050E17] space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Harvest Subtotal</span>
                  <span className="font-mono text-slate-200">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Refrigerated Delivery (0°C–2°C)</span>
                  <span className="font-mono text-slate-200">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-400">FREE</span>
                    ) : (
                      formatPrice(deliveryFee)
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Insulated Sea-Ice Packaging</span>
                  <span className="text-emerald-400 font-mono">Complimentary</span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-white pt-2 border-t border-slate-800">
                  <span>Estimated Total</span>
                  <span className="font-mono text-amber-400 text-base tabular-nums">
                    {formatPrice(total)}
                  </span>
                </div>
              </div>

              <button
                onClick={onProceedToCheckout}
                className="w-full py-3.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-xl shadow-amber-500/10 cursor-pointer"
              >
                <span>Proceed to Secure Checkout</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>256-bit Encrypted Checkout · Doorstep Quality Guarantee</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
