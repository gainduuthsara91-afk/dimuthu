import React, { useState, useEffect, useRef } from 'react';
import { X, Mail, Phone, MapPin, Clock, ShieldCheck, CheckCircle2, MessageCircle, RefreshCw, Send, Lock, KeyRound, LogOut, AlertCircle, ShieldAlert, Cloud } from 'lucide-react';
import { Order } from '../types/seafood';
import { formatPrice } from '../utils/format';

interface OwnerInboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  onOpenSecurity?: () => void;
  onOpenGoogleDrive?: () => void;
}

export const OwnerInboxModal: React.FC<OwnerInboxModalProps> = ({ 
  isOpen, 
  onClose, 
  orders,
  onOpenSecurity,
  onOpenGoogleDrive
}) => {
  const OWNER_EMAIL = 'gainduuthsara91@gmail.com';

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('gvd_owner_authenticated') === 'true';
  });
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [remainingAttempts, setRemainingAttempts] = useState<number | null>(null);
  const [isLocked, setIsLocked] = useState(false);
  const [lockSeconds, setLockSeconds] = useState(0);
  const [isSubmittingPin, setIsSubmittingPin] = useState(false);

  const [syncedOrders, setSyncedOrders] = useState<Order[]>(orders);
  const [isLoading, setIsLoading] = useState(false);
  const [resentStatus, setResentStatus] = useState<Record<string, boolean>>({});

  // 15-minute inactivity auto-lockout
  const inactivityTimerRef = useRef<NodeJS.Timeout | null>(null);

  const resetInactivityTimer = () => {
    if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
    if (isAuthenticated) {
      inactivityTimerRef.current = setTimeout(() => {
        handleLock();
      }, 15 * 60 * 1000); // 15 minutes
    }
  };

  useEffect(() => {
    const handleActivity = () => resetInactivityTimer();
    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keydown', handleActivity);
    resetInactivityTimer();

    return () => {
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
    };
  }, [isAuthenticated]);

  // Lockout countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isLocked && lockSeconds > 0) {
      interval = setInterval(() => {
        setLockSeconds((prev) => {
          if (prev <= 1) {
            setIsLocked(false);
            setPinError('');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLocked, lockSeconds]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchOrdersFromBackend();
    }
  }, [isOpen, isAuthenticated]);

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;

    setIsSubmittingPin(true);
    setPinError('');

    try {
      const res = await fetch('/api/owner/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: pinInput })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setIsAuthenticated(true);
        sessionStorage.setItem('gvd_owner_authenticated', 'true');
        if (data.token) {
          sessionStorage.setItem('gvd_owner_token', data.token);
        }
        setPinError('');
        setPinInput('');
        setRemainingAttempts(null);
        fetchOrdersFromBackend();
      } else if (res.status === 429 || data.locked) {
        setIsLocked(true);
        setLockSeconds(data.remainingLockSeconds || 900);
        setPinError(data.message || 'Security lockout active. Please wait before retrying.');
      } else {
        if (typeof data.remainingAttempts === 'number') {
          setRemainingAttempts(data.remainingAttempts);
        }
        setPinError(data.message || 'Incorrect Owner PIN. Please use your 4-digit PIN (8454).');
      }
    } catch (err) {
      // Offline fallback: check 8454 directly
      const clean = pinInput.trim().toLowerCase();
      if (clean === '8454' || clean === 'lakmal8454') {
        setIsAuthenticated(true);
        sessionStorage.setItem('gvd_owner_authenticated', 'true');
        setPinError('');
        setPinInput('');
        fetchOrdersFromBackend();
      } else {
        setPinError('Incorrect Owner PIN. Please check your 4-digit PIN (8454).');
      }
    } finally {
      setIsSubmittingPin(false);
    }
  };

  const handleLock = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('gvd_owner_authenticated');
    sessionStorage.removeItem('gvd_owner_token');
    setPinInput('');
    setPinError('');
  };

  const fetchOrdersFromBackend = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        if (data.orders && data.orders.length > 0) {
          setSyncedOrders(data.orders);
        }
      }
    } catch (e) {
      setSyncedOrders(orders);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendEmail = (order: Order) => {
    const subject = encodeURIComponent(`Seafood Order #${order.id} - ${order.customerName}`);
    const body = encodeURIComponent(
      `ORDER NOTIFICATION FOR G.V.D.LAKMAL SEAFOOD\n` +
      `Order ID: #${order.id}\n` +
      `Time Placed: ${order.createdAt}\n\n` +
      `CUSTOMER CONTACT & DELIVERY:\n` +
      `Name: ${order.customerName}\n` +
      `Phone: ${order.customerPhone}\n` +
      `Email: ${order.customerEmail}\n` +
      `Address: ${order.address}, ${order.city} (${order.postalCode || ''})\n` +
      `Time Window: ${order.deliverySlot}\n` +
      `Delivery Notes: ${order.deliveryInstructions || 'None'}\n\n` +
      `CATCH ORDERED:\n` +
      order.items.map(i => `• ${i.product?.name || 'Seafood'} (${i.weightKg}kg) - Cut: ${i.selectedPrep} - Rs. ${(i.totalPrice * i.quantity).toLocaleString()}`).join('\n') +
      `\n\nTotal Due: Rs. ${Number(order.totalAmount).toLocaleString()} (${order.paymentMethod?.toUpperCase()})`
    );

    window.open(`mailto:${OWNER_EMAIL}?subject=${subject}&body=${body}`, '_blank');
    setResentStatus(prev => ({ ...prev, [order.id]: true }));
    setTimeout(() => {
      setResentStatus(prev => ({ ...prev, [order.id]: false }));
    }, 3000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-3xl rounded-2xl bg-[#091726] border border-slate-800 shadow-2xl overflow-hidden my-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-[#06111D]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white p-1 border border-slate-700/80 flex items-center justify-center shrink-0 overflow-hidden shadow-sm">
              <img
                src="/assets/aistudio/Modern_Navy_Seafood_Logo_fceeff00.png"
                alt="G.V.D.Lakmal Seafood Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-lg font-semibold text-white">
                  Owner Order Dispatch Portal
                </h2>
                {isAuthenticated ? (
                  <span className="text-[10px] font-mono uppercase bg-emerald-950 border border-emerald-800/80 px-2 py-0.5 rounded text-emerald-400 font-medium">
                    Unlocked
                  </span>
                ) : (
                  <span className="text-[10px] font-mono uppercase bg-amber-950/60 border border-amber-800/80 px-2 py-0.5 rounded text-amber-400 font-medium">
                    Owner Protected
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                Connected Dispatch Gmail: <strong className="text-amber-300 font-mono">{OWNER_EMAIL}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenSecurity && (
              <button
                onClick={onOpenSecurity}
                className="px-2.5 py-1 text-xs text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-800/80 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                title="View Security Diagnostics"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Security Shield</span>
              </button>
            )}

            {onOpenGoogleDrive && (
              <button
                onClick={onOpenGoogleDrive}
                className="px-2.5 py-1 text-xs text-sky-300 bg-sky-950/60 hover:bg-sky-900 border border-sky-800/80 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                title="Open Google Drive Cloud Records"
              >
                <Cloud className="w-3.5 h-3.5 text-sky-400" />
                <span className="hidden sm:inline">Google Drive</span>
              </button>
            )}

            {isAuthenticated && (
              <>
                <button
                  onClick={fetchOrdersFromBackend}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Refresh Orders"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                </button>
                <button
                  onClick={handleLock}
                  className="px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Lock Portal"
                >
                  <LogOut className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">Lock Portal</span>
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close inbox"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* LOCKED SCREEN FOR NON-OWNER VISITORS */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-12 text-center flex flex-col items-center justify-center space-y-6">
            <div className="w-20 h-20 rounded-2xl bg-white p-1.5 shadow-xl border border-slate-700/80 overflow-hidden flex items-center justify-center">
              <img
                src="/assets/aistudio/Modern_Navy_Seafood_Logo_fceeff00.png"
                alt="G.V.D.Lakmal Seafood Logo"
                className="w-full h-full object-contain"
              />
            </div>

            <div className="max-w-md space-y-2">
              <h3 className="font-serif text-xl font-bold text-white">
                Restricted to Business Owner
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                This inbox contains customer addresses, phone numbers, and delivery instructions for G.V.D.Lakmal Seafood. Enter your Owner PIN to review customer orders.
              </p>
            </div>

            {/* Brute-force lockout alert if active */}
            {isLocked ? (
              <div className="w-full max-w-sm p-4 rounded-xl bg-rose-950/40 border border-rose-800 text-rose-300 text-xs space-y-2">
                <div className="flex items-center justify-center gap-2 font-bold text-rose-400 text-sm">
                  <ShieldAlert className="w-5 h-5" />
                  <span>Security Lockout Enforced</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Too many incorrect PIN attempts were detected. System defenses have temporarily locked access from this device to safeguard customer data.
                </p>
                <div className="font-mono text-base font-bold text-white pt-1">
                  Unlocking in: {Math.floor(lockSeconds / 60)}m {lockSeconds % 60}s
                </div>
              </div>
            ) : (
              <form onSubmit={handleUnlock} className="w-full max-w-sm space-y-4">
                <div className="space-y-1.5 text-left">
                  <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
                    <span>Enter Owner PIN</span>
                    <span className="text-[11px] text-amber-400/80 font-mono">Default PIN: 8454</span>
                  </label>
                  <div className="relative">
                    <input
                      type="password"
                      value={pinInput}
                      onChange={(e) => {
                        setPinInput(e.target.value);
                        if (pinError) setPinError('');
                      }}
                      placeholder="Enter 4-digit PIN (8454)"
                      className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-xl text-center text-lg font-mono tracking-widest text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
                      autoFocus
                    />
                  </div>

                  {/* Warning on remaining attempts before ban */}
                  {remainingAttempts !== null && remainingAttempts < 5 && remainingAttempts > 0 && (
                    <p className="text-[11px] text-amber-400 flex items-center gap-1 mt-1 font-mono">
                      <span>⚠️ {remainingAttempts} attempts remaining before 15-minute security lockout.</span>
                    </p>
                  )}

                  {pinError && (
                    <p className="text-xs text-rose-400 flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{pinError}</span>
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isSubmittingPin}
                  className="w-full py-3 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-semibold text-sm rounded-xl shadow-lg shadow-amber-500/15 cursor-pointer transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Lock className="w-4 h-4" />
                  <span>{isSubmittingPin ? 'Verifying Defenses...' : 'Unlock Owner Portal'}</span>
                </button>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/80">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Rate-Limited Shield</span>
                  </span>
                  <span>WhatsApp: <strong className="text-emerald-400 font-mono">077 878 8454</strong></span>
                </div>
              </form>
            )}
          </div>
        ) : (
          /* AUTHENTICATED OWNER VIEW */
          <>
            {/* Info Banner */}
            <div className="bg-sky-950/30 border-b border-slate-800 p-3.5 px-6 flex items-center justify-between text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  Every customer order dispatches directly to <strong>{OWNER_EMAIL}</strong> with delivery details.
                </span>
              </div>
              <span className="font-mono text-amber-400 shrink-0 hidden sm:inline">
                {syncedOrders.length} Received Orders
              </span>
            </div>

            {/* Order Cards List */}
            <div className="p-6 max-h-[65vh] overflow-y-auto space-y-4">
              {syncedOrders.length === 0 ? (
                <div className="py-16 text-center text-slate-400 text-xs">
                  No orders have been received yet. Test by placing a fresh catch order in checkout!
                </div>
              ) : (
                syncedOrders.map((order) => {
                  const isResent = resentStatus[order.id];

                  return (
                    <div
                      key={order.id}
                      className="p-5 rounded-xl border border-slate-800 bg-[#07131F] space-y-3 transition-colors hover:border-slate-700"
                    >
                      {/* Top Bar of Card */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm font-bold text-amber-400">
                            #{order.id}
                          </span>
                          <span className="text-slate-600">·</span>
                          <span className="text-xs text-slate-400">{order.createdAt}</span>
                          <span className="text-slate-600">·</span>
                          <span className="text-[11px] font-mono uppercase bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-emerald-400">
                            {order.paymentMethod?.toUpperCase()} · {order.paymentStatus || 'CASH ON DELIVERY'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleResendEmail(order)}
                            className="px-2.5 py-1 text-[11px] bg-slate-900 hover:bg-slate-800 text-sky-300 border border-slate-700/80 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <Send className="w-3 h-3" />
                            <span>{isResent ? 'Email Opened!' : 'Open Email'}</span>
                          </button>

                          <a
                            href={`https://wa.me/${order.customerPhone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 text-[11px] bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800/80 rounded-lg flex items-center gap-1.5 transition-colors"
                          >
                            <MessageCircle className="w-3 h-3 fill-emerald-400 text-slate-950" />
                            <span>WhatsApp Customer</span>
                          </a>
                        </div>
                      </div>

                      {/* Customer Information Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-950/60 p-3 rounded-lg border border-slate-800/60">
                        <div>
                          <span className="text-[10px] text-slate-500 uppercase font-mono block">Customer Name</span>
                          <span className="text-white font-medium text-sm">{order.customerName}</span>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-500 uppercase font-mono block">Mobile Phone</span>
                          <a href={`tel:${order.customerPhone}`} className="text-sky-400 font-mono hover:underline">
                            {order.customerPhone}
                          </a>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-500 uppercase font-mono block">Delivery Address</span>
                          <span className="text-slate-300">
                            {order.address}, {order.city} ({order.postalCode || 'Postal N/A'})
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-500 uppercase font-mono block">What Time Needed</span>
                          <span className="text-amber-300 font-medium">{order.deliverySlot}</span>
                        </div>

                        {order.deliveryInstructions && (
                          <div className="sm:col-span-2 text-slate-400 italic">
                            <strong className="text-slate-300 not-italic">Notes:</strong> "{order.deliveryInstructions}"
                          </div>
                        )}
                      </div>

                      {/* Catch Items Summary */}
                      <div className="space-y-1.5 pt-1 text-xs">
                        <span className="text-[10px] text-slate-500 uppercase font-mono block">
                          Seafood Items ({order.items.length}):
                        </span>
                        <div className="space-y-1">
                          {order.items.map((item, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between bg-slate-900/50 px-3 py-1.5 rounded border border-slate-800/60 text-[11px]"
                            >
                              <div>
                                <span className="text-white font-medium">{item.product?.name || 'Seafood Catch'}</span>
                                <span className="text-slate-500 ml-2">({item.weightKg} kg)</span>
                                <span className="text-amber-400 ml-2">· Cut: {item.selectedPrep}</span>
                              </div>
                              <span className="font-mono text-slate-300">
                                {formatPrice((item.totalPrice || 0) * (item.quantity || 1))}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Total Amount Due */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                        <span className="text-slate-400">Total Billed:</span>
                        <span className="font-mono text-base font-bold text-amber-400 tabular-nums">
                          {formatPrice(Number(order.totalAmount))}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 bg-[#06111D] flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>Active Session (15m Auto-Lock) · Relay: <span className="text-white font-mono">{OWNER_EMAIL}</span></span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleLock}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer text-xs"
                >
                  Lock
                </button>
                <button
                  onClick={onClose}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-lg transition-colors cursor-pointer text-xs"
                >
                  Done
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
