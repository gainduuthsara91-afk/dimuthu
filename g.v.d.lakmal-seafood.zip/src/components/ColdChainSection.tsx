import React from 'react';
import { ThermometerSnowflake, ShieldCheck, Box, Truck, CheckCircle2, AlertCircle } from 'lucide-react';

export const ColdChainSection: React.FC = () => {
  return (
    <section id="cold-chain" className="py-20 border-t border-slate-800/80 bg-[#06101B] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-sky-400 mb-2">
            <span>The Temperature Promise</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>0°C to 2°C Marine Preservation</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-white [text-wrap:balance]">
            Delivered straight to your door, untouched by ambient heat.
          </h2>
          <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
            Seafood degrades primarily due to bacterial bloom when temperature fluctuates above 4°C. At <strong className="text-white">G.V.D.Lakmal Seafood</strong>, every fish is submersed in natural sea-ice slurry within seconds of line landing, and stays in a monitored cold chain until your kitchen counter.
          </p>
        </div>

        {/* 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch mb-16">
          
          {/* Packaging & Logistics Visual */}
          <div className="lg:col-span-6 relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 shadow-xl group">
            <img
              src="/src/assets/images/cold_chain_delivery_1792667469630.jpg"
              alt="G.V.D.Lakmal Seafood insulated cold-chain delivery box"
              className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07131F] via-[#07131F]/30 to-transparent pointer-events-none" />

            {/* Packaging Spec Overlay */}
            <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#091726]/95 border border-slate-700/80 backdrop-blur-md">
              <div className="flex items-center justify-between text-xs font-mono text-amber-400 mb-1">
                <span>Insulated Sea-Ice Thermal Pack</span>
                <span className="text-sky-300 font-semibold">Holds 0°C for 36 Hours</span>
              </div>
              <p className="text-xs text-slate-300">
                100% recyclable FSC certified cardboard with biodegradable natural wool insulation pads and dry gel ice packs.
              </p>
            </div>
          </div>

          {/* 4-Step Chain of Freshness */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-4">
            
            <div className="p-5 rounded-xl border border-slate-800/90 bg-[#091726] transition-colors hover:border-slate-700">
              <div className="flex items-center gap-3 mb-2">
                <span className="font-mono text-sm font-bold text-amber-400">01.</span>
                <h3 className="font-serif text-lg font-semibold text-white">
                  Dawn Deep-Water Harvest & Sea-Ice Slurry
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-7">
                Fish are brought aboard by small artisan day-boats and placed immediately in crushed sea-ice slurry, bringing core muscle temperature down to 1°C in under 12 minutes.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800/90 bg-[#091726] transition-colors hover:border-slate-700">
              <div className="flex items-center gap-3 mb-2">
                <span className="font-mono text-sm font-bold text-amber-400">02.</span>
                <h3 className="font-serif text-lg font-semibold text-white">
                  Pier-Side Inspection & Grade Sorting
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-7">
                At Mirissa & Negombo harbor docks, our chief quality inspector grades flesh clarity, fat content, gill redness, and eye clarity. Only export-first tier catches are tagged for direct delivery.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800/90 bg-[#091726] transition-colors hover:border-slate-700">
              <div className="flex items-center gap-3 mb-2">
                <span className="font-mono text-sm font-bold text-amber-400">03.</span>
                <h3 className="font-serif text-lg font-semibold text-white">
                  Precision Cut & Vacuum Sub-Zero Seal
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-7">
                Your order is portioned by trained fishmongers in our sanitary, temperature-controlled facility (12°C ambient) and sealed in food-grade vacuum pouches with moisture absorbers.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800/90 bg-[#091726] transition-colors hover:border-slate-700">
              <div className="flex items-center gap-3 mb-2">
                <span className="font-mono text-sm font-bold text-amber-400">04.</span>
                <h3 className="font-serif text-lg font-semibold text-white">
                  Refrigerated Courier to Your Kitchen
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-7">
                Dispatched in temperature-controlled vans with digital data loggers. Handed to your door in our thermal sea-ice box with tamper-evident seal and temperature stamp.
              </p>
            </div>

          </div>

        </div>

        {/* Rigorous Comparison Table: Standard vs G.V.D.Lakmal */}
        <div className="rounded-2xl border border-slate-800 bg-[#091726] overflow-hidden">
          <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="font-serif text-lg sm:text-xl font-semibold text-white">
                Freshness Integrity Comparison
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Scientific quality benchmarks between grocery market counters and our direct harbor chain.
              </p>
            </div>
            <span className="font-mono text-xs text-amber-400 hidden sm:inline">HACCP Class A Benchmark</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-900/80 text-slate-400 uppercase font-mono text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-6">Quality Factor</th>
                  <th className="py-3 px-6 text-slate-400">Standard Supermarket Seafood</th>
                  <th className="py-3 px-6 text-amber-300 font-semibold">G.V.D.Lakmal Seafood Direct</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr>
                  <td className="py-4 px-6 font-medium text-white">Time from Ocean Landing</td>
                  <td className="py-4 px-6 text-slate-400">4 to 9 days through wholesale middlemen</td>
                  <td className="py-4 px-6 text-emerald-400 font-medium font-mono">Under 4 to 8 hours direct</td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium text-white">Cold Chain Management</td>
                  <td className="py-4 px-6 text-slate-400">Frequent temperature spikes in open display cases</td>
                  <td className="py-4 px-6 text-emerald-400 font-medium font-mono">Unbroken 0°C–2°C with data logging</td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium text-white">Chemical Preservatives</td>
                  <td className="py-4 px-6 text-slate-400">Often treated with tripolyphosphates to retain water</td>
                  <td className="py-4 px-6 text-emerald-400 font-medium font-mono">100% Zero chemicals, only natural sea ice</td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium text-white">Cutting & Preparation</td>
                  <td className="py-4 px-6 text-slate-400">Pre-cut in central factory days in advance</td>
                  <td className="py-4 px-6 text-emerald-400 font-medium font-mono">Hand-cut to your custom order at dawn</td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium text-white">Sushi / Sashimi Safety</td>
                  <td className="py-4 px-6 text-rose-400">Not recommended for raw consumption</td>
                  <td className="py-4 px-6 text-emerald-400 font-medium font-mono">AAA+ Verified Raw & Sashimi Grade</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
  );
};
