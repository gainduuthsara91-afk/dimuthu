import React from 'react';
import { Star, ShieldCheck } from 'lucide-react';
import { REVIEWS } from '../data/seafoodData';

export const Reviews: React.FC = () => {
  return (
    <section id="reviews" className="py-20 border-t border-slate-800/80 bg-[#06101B] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-amber-400 mb-2">
            <span>Verified Taste Endorsements</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Chefs & Discerning Epicures</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-white [text-wrap:balance]">
            Trusted by the island’s finest kitchens.
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-2">
            Direct feedback from executive resort chefs, private yacht caterers, and home gourmands.
          </p>
        </div>

        {/* 3 Attributable Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {REVIEWS.map((review) => (
            <div
              key={review.author}
              className="p-6 rounded-2xl border border-slate-800 bg-[#091726] flex flex-col justify-between"
            >
              <div>
                {/* 5 Stars */}
                <div className="flex items-center gap-1 text-amber-400 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Quote */}
                <blockquote className="text-slate-300 text-sm leading-relaxed mb-6 italic">
                  "{review.quote}"
                </blockquote>
              </div>

              {/* Attribution */}
              <div className="pt-4 border-t border-slate-800/80">
                <div className="text-sm font-semibold text-white">
                  {review.author}
                </div>
                <div className="text-xs text-slate-400">
                  {review.role} · <span className="text-slate-300">{review.organization}</span>
                </div>
                
                {/* Verified Order Tag */}
                <div className="flex items-center gap-1.5 mt-2.5 text-[11px] text-emerald-400 font-mono">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Verified Catch: {review.verifiedOrder}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
