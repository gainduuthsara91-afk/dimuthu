# 🐟 G.V.D.Lakmal Seafood — Web Application

Official web storefront & fresh catch delivery platform for **G.V.D.Lakmal Seafood (Mirissa Fishery Harbor, Sri Lanka)**.

---

## 🚀 Quick Start (Running Locally)

### 1. Requirements
- Node.js (version 18, 20, or 22 recommended)
- npm or bun

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Development Server
```bash
npm run dev
```
Open your browser at **`http://localhost:3000`**.

---

## 📦 Building & Running in Production

To build optimized assets and run the Express + Vite production server:

```bash
# Build client assets into /dist
npm run build

# Start the production server
npm start
```
The server will run on `http://localhost:3000` (or the port specified by the `PORT` environment variable).

---

## 🌐 How to Publish Online (Free & Easy Hosting)

Your website is a full-stack **Node.js (Express) + React (Vite)** app. You can deploy it to any cloud host in just a few clicks:

### Option 1: Render.com (Recommended — Free Tier Available)
1. Push this project to GitHub (or upload it).
2. Sign in to [render.com](https://render.com) and click **"New Web Service"**.
3. Connect your GitHub repository.
4. Set the following settings:
   - **Environment**: `Node`
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
5. Click **"Deploy Web Service"**. Your live URL (e.g. `gvd-lakmal-seafood.onrender.com`) will be active with free automatic SSL/HTTPS!

### Option 2: Railway.app
1. Go to [railway.app](https://railway.app).
2. Click **"New Project"** -> **"Deploy from GitHub repo"**.
3. Railway automatically detects Node.js, runs `npm run build`, and starts `npm start`.
4. Add a custom domain under service settings (e.g., `gvdseafood.com`).

### Option 3: VPS / Ubuntu / DigitalOcean Droplet
1. Install Node.js: `sudo apt update && sudo apt install nodejs npm`
2. Install PM2: `npm install -g pm2`
3. Clone or copy your files onto the server.
4. Run:
   ```bash
   npm install
   npm run build
   pm2 start "npm start" --name gvd-seafood
   ```
5. Set up Nginx reverse proxy pointing to `http://127.0.0.1:3000`.

---

## 🔑 Environment Variables (Optional)

Create a `.env` file based on `.env.example`:
- `PORT`: Server port (default: `3000`)
- `OWNER_EMAIL`: Set to `gainduuthsara91@gmail.com`
- `SMTP_USER` & `SMTP_PASS`: (Optional) Gmail App Password for direct SMTP notification relay. (The built-in FormSubmit relay already works automatically).

---

## 🛡️ Built-in Security & Features
- **Unlimited Order Weight**: Customers can order custom quantities/weights.
- **Enterprise Defense Shield**: HSTS, X-Frame-Options, XSS protection, anti-bot honeypots, rate limiting, and brute-force protection for Owner PIN (`8454`).
- **Owner Inbox**: Access orders at `gainduuthsara91@gmail.com` and via the in-app secure Owner Inbox.
- **WhatsApp Pier Dispatch**: Direct 1-tap WhatsApp chat with `077 878 8454` (+94778788454).
